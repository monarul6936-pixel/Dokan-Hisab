package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.People
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.Customer
import com.example.ui.components.DokanTopBar
import com.example.ui.screens.AccountsScreen
import com.example.ui.screens.CollectionScreen
import com.example.ui.screens.CustomersScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ExpenseScreen
import com.example.ui.screens.ProductsScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SaleScreen
import com.example.ui.screens.SignInScreen
import com.example.ui.screens.SuppliersScreen
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CrimsonDue
import com.example.ui.theme.EmeraldGreenPrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.DokanViewModel
import kotlinx.coroutines.flow.collectLatest

enum class DokanScreen(val title: String, val icon: ImageVector) {
  DASHBOARD("হোম", Icons.Default.Dashboard),
  SALE("বিক্রি", Icons.Default.AddShoppingCart),
  PRODUCTS("পণ্য", Icons.Default.Inventory),
  CUSTOMERS("খাতা", Icons.Default.People),
  SUPPLIERS("মহাজন", Icons.Default.Business),
  ACCOUNTS("ক্যাশ/ব্যাংক", Icons.Default.AccountBalanceWallet),
  COLLECTION("আদায়", Icons.Default.Payment),
  EXPENSE("খরচ", Icons.Default.MoneyOff),
  REPORTS("রিপোর্ট", Icons.Default.Assessment)
}

class MainActivity : ComponentActivity() {
  private val viewModel: DokanViewModel by viewModels()

  @OptIn(ExperimentalMaterial3Api::class)
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      MyApplicationTheme {
        val currentUser by viewModel.currentUser.collectAsState()

        if (currentUser == null) {
          SignInScreen(
            onSignInSuccess = {
              viewModel.onUserSignedIn()
            }
          )
        } else {
          DokanMainScaffold(viewModel = viewModel)
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DokanMainScaffold(viewModel: DokanViewModel) {
  val shopName by viewModel.shopName.collectAsState()
  val summary by viewModel.summary.collectAsState()
  val snackbarHostState = remember { SnackbarHostState() }

  var currentScreen by remember { mutableStateOf(DokanScreen.DASHBOARD) }
  var customerForCollection by remember { mutableStateOf<Customer?>(null) }
  var showMoreSheet by remember { mutableStateOf(false) }

  // BackHandler: Return to Dashboard if on any sub-screen
  BackHandler(enabled = currentScreen != DokanScreen.DASHBOARD) {
    currentScreen = DokanScreen.DASHBOARD
  }

  // Toast / snackbar notifications
  LaunchedEffect(Unit) {
    viewModel.userMessage.collectLatest { msg ->
      snackbarHostState.showSnackbar(msg)
    }
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    topBar = {
      DokanTopBar(
        shopName = shopName,
        onProfileClick = {
          currentScreen = DokanScreen.REPORTS
        }
      )
    },
    bottomBar = {
      NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
      ) {
        val navItems = listOf(
          DokanScreen.DASHBOARD,
          DokanScreen.SALE,
          DokanScreen.PRODUCTS,
          DokanScreen.CUSTOMERS
        )

        navItems.forEach { screen ->
          val isSelected = currentScreen == screen
          NavigationBarItem(
            selected = isSelected,
            onClick = { currentScreen = screen },
            icon = {
              if (screen == DokanScreen.PRODUCTS && summary.lowStockCount > 0) {
                BadgedBox(
                  badge = {
                    Badge(containerColor = CrimsonDue) {
                      Text("${summary.lowStockCount}")
                    }
                  }
                ) {
                  Icon(screen.icon, contentDescription = screen.title)
                }
              } else {
                Icon(screen.icon, contentDescription = screen.title)
              }
            },
            label = {
              Text(
                text = screen.title,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = EmeraldGreenPrimary,
              selectedTextColor = EmeraldGreenPrimary,
              indicatorColor = EmeraldGreenPrimary.copy(alpha = 0.15f)
            ),
            modifier = Modifier.testTag("nav_${screen.name.lowercase()}")
          )
        }

        // "More" / Menu Button for Suppliers, Accounts, Expense, Collection, Reports
        val isMoreSelected = currentScreen in listOf(
          DokanScreen.SUPPLIERS,
          DokanScreen.ACCOUNTS,
          DokanScreen.COLLECTION,
          DokanScreen.EXPENSE,
          DokanScreen.REPORTS
        )

        NavigationBarItem(
          selected = isMoreSelected,
          onClick = { showMoreSheet = true },
          icon = {
            Icon(
              imageVector = when (currentScreen) {
                DokanScreen.SUPPLIERS -> Icons.Default.Business
                DokanScreen.ACCOUNTS -> Icons.Default.AccountBalanceWallet
                DokanScreen.COLLECTION -> Icons.Default.Payment
                DokanScreen.EXPENSE -> Icons.Default.MoneyOff
                DokanScreen.REPORTS -> Icons.Default.Assessment
                else -> Icons.Default.Menu
              },
              contentDescription = "মেনু"
            )
          },
          label = {
            Text(
              text = when (currentScreen) {
                DokanScreen.SUPPLIERS -> "মহাজন"
                DokanScreen.ACCOUNTS -> "ব্যাংক"
                DokanScreen.COLLECTION -> "আদায়"
                DokanScreen.EXPENSE -> "খরচ"
                DokanScreen.REPORTS -> "রিপোর্ট"
                else -> "মেনু"
              },
              fontWeight = if (isMoreSelected) FontWeight.Bold else FontWeight.Normal
            )
          },
          colors = NavigationBarItemDefaults.colors(
            selectedIconColor = EmeraldGreenPrimary,
            selectedTextColor = EmeraldGreenPrimary,
            indicatorColor = EmeraldGreenPrimary.copy(alpha = 0.15f)
          ),
          modifier = Modifier.testTag("nav_more")
        )
      }
    },
    snackbarHost = { SnackbarHost(snackbarHostState) }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      AnimatedContent(
        targetState = currentScreen,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "screen_transition"
      ) { screen ->
        when (screen) {
          DokanScreen.DASHBOARD -> DashboardScreen(
            viewModel = viewModel,
            onNavigateToSale = { currentScreen = DokanScreen.SALE },
            onNavigateToCustomers = { currentScreen = DokanScreen.CUSTOMERS },
            onNavigateToSuppliers = { currentScreen = DokanScreen.SUPPLIERS },
            onNavigateToAccounts = { currentScreen = DokanScreen.ACCOUNTS },
            onNavigateToCollection = {
              customerForCollection = null
              currentScreen = DokanScreen.COLLECTION
            },
            onNavigateToExpense = { currentScreen = DokanScreen.EXPENSE },
            onNavigateToProducts = { currentScreen = DokanScreen.PRODUCTS }
          )

          DokanScreen.SALE -> SaleScreen(
            viewModel = viewModel
          )

          DokanScreen.PRODUCTS -> ProductsScreen(
            viewModel = viewModel
          )

          DokanScreen.CUSTOMERS -> CustomersScreen(
            viewModel = viewModel,
            onNavigateToCollectionForCustomer = { customer ->
              customerForCollection = customer
              currentScreen = DokanScreen.COLLECTION
            }
          )

          DokanScreen.SUPPLIERS -> SuppliersScreen(
            viewModel = viewModel
          )

          DokanScreen.ACCOUNTS -> AccountsScreen(
            viewModel = viewModel
          )

          DokanScreen.COLLECTION -> CollectionScreen(
            viewModel = viewModel,
            preselectedCustomer = customerForCollection
          )

          DokanScreen.EXPENSE -> ExpenseScreen(
            viewModel = viewModel
          )

          DokanScreen.REPORTS -> ReportsScreen(
            viewModel = viewModel
          )
        }
      }
    }

    // Modal BottomSheet for More Options
    if (showMoreSheet) {
      ModalBottomSheet(
        onDismissRequest = { showMoreSheet = false },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Text(
            text = "দোকানের অতিরিক্ত মেনু",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 4.dp)
          )

          MoreMenuItem(
            title = "মহাজন / পাইকার খাতা (Suppliers)",
            subtitle = "পাইকারি ক্রয় রসিদ ও মহাজন দেনা পরিশোধ",
            icon = Icons.Default.Business,
            accentColor = AmberAccent,
            onClick = {
              showMoreSheet = false
              currentScreen = DokanScreen.SUPPLIERS
            }
          )

          MoreMenuItem(
            title = "ক্যাশ বাক্স ও ব্যাংকিং (Accounts)",
            subtitle = "নগদ টাকা, বিকাশ, নগদ ও ব্যাংক ব্যালেন্স",
            icon = Icons.Default.AccountBalanceWallet,
            accentColor = EmeraldGreenPrimary,
            onClick = {
              showMoreSheet = false
              currentScreen = DokanScreen.ACCOUNTS
            }
          )

          MoreMenuItem(
            title = "বাকি আদায় (Collection)",
            subtitle = "কাস্টমারের বাকি টাকা জমা নেওয়া",
            icon = Icons.Default.Payment,
            accentColor = EmeraldGreenPrimary,
            onClick = {
              showMoreSheet = false
              customerForCollection = null
              currentScreen = DokanScreen.COLLECTION
            }
          )

          MoreMenuItem(
            title = "দোকানের খরচ ও অপচয় (Expenses)",
            subtitle = "দৈনন্দিন খরচ, বিদ্যুৎ বিল, দোকান ভাড়া",
            icon = Icons.Default.MoneyOff,
            accentColor = CrimsonDue,
            onClick = {
              showMoreSheet = false
              currentScreen = DokanScreen.EXPENSE
            }
          )

          MoreMenuItem(
            title = "রিপোর্ট, ব্যালেন্স শিট ও সেটিংস",
            subtitle = "লাভ-ক্ষতি বিবরণী, মোট সম্পত্তি ও প্রোফাইল",
            icon = Icons.Default.Assessment,
            accentColor = EmeraldGreenPrimary,
            onClick = {
              showMoreSheet = false
              currentScreen = DokanScreen.REPORTS
            }
          )

          Spacer(modifier = Modifier.height(24.dp))
        }
      }
    }
  }
}

@Composable
private fun MoreMenuItem(
  title: String,
  subtitle: String,
  icon: ImageVector,
  accentColor: Color,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .clickable(onClick = onClick),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(42.dp)
          .clip(CircleShape)
          .background(accentColor.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = icon,
          contentDescription = title,
          tint = accentColor,
          modifier = Modifier.size(22.dp)
        )
      }
      Spacer(modifier = Modifier.width(14.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }
}
