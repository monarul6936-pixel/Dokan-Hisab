package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
  @Query("SELECT * FROM products ORDER BY name ASC")
  fun getAllProductsFlow(): Flow<List<ProductEntity>>

  @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
  suspend fun getProductById(id: String): ProductEntity?

  @Query("SELECT * FROM products WHERE stock <= :threshold ORDER BY stock ASC")
  fun getLowStockProductsFlow(threshold: Double = 5.0): Flow<List<ProductEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProduct(product: ProductEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(products: List<ProductEntity>)

  @Update
  suspend fun updateProduct(product: ProductEntity)

  @Query("UPDATE products SET stock = stock - :quantity WHERE id = :id")
  suspend fun deductStock(id: String, quantity: Double)

  @Query("UPDATE products SET stock = stock + :quantity WHERE id = :id")
  suspend fun addStock(id: String, quantity: Double)

  @Delete
  suspend fun deleteProduct(product: ProductEntity)

  @Query("DELETE FROM products WHERE id = :id")
  suspend fun deleteProductById(id: String)

  @Query("DELETE FROM products")
  suspend fun clearAll()
}

@Dao
interface CustomerDao {
  @Query("SELECT * FROM customers ORDER BY name ASC")
  fun getAllCustomersFlow(): Flow<List<CustomerEntity>>

  @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
  suspend fun getCustomerById(id: String): CustomerEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCustomer(customer: CustomerEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(customers: List<CustomerEntity>)

  @Update
  suspend fun updateCustomer(customer: CustomerEntity)

  @Query("DELETE FROM customers WHERE id = :id")
  suspend fun deleteCustomerById(id: String)

  @Query("DELETE FROM customers")
  suspend fun clearAll()
}

@Dao
interface TransactionDao {
  @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
  fun getAllTransactionsFlow(): Flow<List<TransactionEntity>>

  @Query("SELECT * FROM transactions ORDER BY timestamp DESC LIMIT :limit")
  fun getRecentTransactionsFlow(limit: Int = 10): Flow<List<TransactionEntity>>

  @Query("SELECT * FROM transactions WHERE customerId = :customerId ORDER BY timestamp DESC")
  fun getCustomerTransactionsFlow(customerId: String): Flow<List<TransactionEntity>>

  @Query("SELECT * FROM transactions WHERE customerId = :customerId")
  suspend fun getCustomerTransactions(customerId: String): List<TransactionEntity>

  @Query("SELECT * FROM transactions WHERE type = :type ORDER BY timestamp DESC")
  fun getTransactionsByTypeFlow(type: String): Flow<List<TransactionEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTransaction(transaction: TransactionEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(transactions: List<TransactionEntity>)

  @Query("DELETE FROM transactions WHERE id = :id")
  suspend fun deleteTransactionById(id: String)

  @Query("DELETE FROM transactions")
  suspend fun clearAll()
}

@Dao
interface ShopDao {
  @Query("SELECT * FROM shop_info WHERE id = 1 LIMIT 1")
  fun getShopFlow(): Flow<ShopEntity?>

  @Query("SELECT * FROM shop_info WHERE id = 1 LIMIT 1")
  suspend fun getShop(): ShopEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun setShop(shop: ShopEntity)
}
