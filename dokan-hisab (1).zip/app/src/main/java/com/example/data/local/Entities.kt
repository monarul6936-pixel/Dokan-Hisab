package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.CartItem
import com.example.data.model.Customer
import com.example.data.model.Product
import com.example.data.model.Transaction

@Entity(tableName = "products")
data class ProductEntity(
  @PrimaryKey val id: String,
  val userId: String = "",
  val name: String,
  val buy: Double,
  val sell: Double,
  val stock: Double,
  val unit: String
) {
  fun toModel(): Product = Product(id, userId, name, buy, sell, stock, unit)
  companion object {
    fun fromModel(p: Product): ProductEntity = ProductEntity(p.id, p.userId, p.name, p.buy, p.sell, p.stock, p.unit)
  }
}

@Entity(tableName = "customers")
data class CustomerEntity(
  @PrimaryKey val id: String,
  val userId: String = "",
  val name: String,
  val phone: String,
  val opening: Double
) {
  fun toModel(): Customer = Customer(id, userId, name, phone, opening)
  companion object {
    fun fromModel(c: Customer): CustomerEntity = CustomerEntity(c.id, c.userId, c.name, c.phone, c.opening)
  }
}

@Entity(tableName = "transactions")
data class TransactionEntity(
  @PrimaryKey val id: String,
  val userId: String = "",
  val date: String,
  val timestamp: Long,
  val type: String,
  val amount: Double,
  val paidAmount: Double = 0.0,
  val dueAmount: Double = 0.0,
  val method: String,
  val accountId: String = "cash",
  val note: String,
  val customerId: String? = null,
  val customerName: String? = null,
  val supplierId: String? = null,
  val supplierName: String? = null,
  val profit: Double? = null,
  val productId: String? = null,
  val productName: String? = null,
  val itemQty: Double? = null,
  val itemBuyPrice: Double? = null,
  val itemSellPrice: Double? = null
) {
  fun toModel(): Transaction {
    val items = if (productId != null && productName != null) {
      listOf(
        CartItem(
          productId = productId,
          name = productName,
          qty = itemQty ?: 1.0,
          buyPrice = itemBuyPrice ?: 0.0,
          sellPrice = itemSellPrice ?: 0.0,
          total = (itemQty ?: 1.0) * (itemSellPrice ?: 0.0)
        )
      )
    } else emptyList()

    return Transaction(
      id = id,
      userId = userId,
      date = date,
      timestamp = timestamp,
      type = type,
      amount = amount,
      paidAmount = paidAmount,
      dueAmount = dueAmount,
      method = method,
      accountId = accountId,
      note = note,
      customerId = customerId,
      customerName = customerName,
      supplierId = supplierId,
      supplierName = supplierName,
      profit = profit,
      items = items
    )
  }

  companion object {
    fun fromModel(t: Transaction): TransactionEntity {
      val firstItem = t.items.firstOrNull()
      return TransactionEntity(
        id = t.id,
        userId = t.userId,
        date = t.date,
        timestamp = t.timestamp,
        type = t.type,
        amount = t.amount,
        paidAmount = t.paidAmount,
        dueAmount = t.dueAmount,
        method = t.method,
        accountId = t.accountId,
        note = t.note,
        customerId = t.customerId,
        customerName = t.customerName,
        supplierId = t.supplierId,
        supplierName = t.supplierName,
        profit = t.profit,
        productId = firstItem?.productId,
        productName = firstItem?.name,
        itemQty = firstItem?.qty,
        itemBuyPrice = firstItem?.buyPrice,
        itemSellPrice = firstItem?.sellPrice
      )
    }
  }
}

@Entity(tableName = "shop_info")
data class ShopEntity(
  @PrimaryKey val id: Int = 1,
  val name: String
)
