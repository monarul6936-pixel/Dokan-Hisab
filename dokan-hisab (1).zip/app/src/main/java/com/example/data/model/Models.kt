package com.example.data.model

import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import java.text.NumberFormat
import java.util.Locale

@IgnoreExtraProperties
data class Product(
  @DocumentId val id: String = "",
  val userId: String = "",
  val name: String = "",
  val buy: Double = 0.0,
  val sell: Double = 0.0,
  val stock: Double = 0.0,
  val unit: String = "টি"
)

@IgnoreExtraProperties
data class Customer(
  @DocumentId val id: String = "",
  val userId: String = "",
  val name: String = "",
  val phone: String = "",
  val opening: Double = 0.0
)

@IgnoreExtraProperties
data class Supplier(
  @DocumentId val id: String = "",
  val userId: String = "",
  val name: String = "",
  val company: String = "",
  val phone: String = "",
  val opening: Double = 0.0
)

@IgnoreExtraProperties
data class Account(
  @DocumentId val id: String = "",
  val userId: String = "",
  val name: String = "",
  val balance: Double = 0.0,
  val type: String = "cash" // "cash", "mobile_banking", "bank"
)

data class CartItem(
  val productId: String = "",
  val name: String = "",
  val qty: Double = 1.0,
  val unit: String = "টি",
  val buyPrice: Double = 0.0,
  val sellPrice: Double = 0.0,
  val total: Double = 0.0
)

@IgnoreExtraProperties
data class Transaction(
  @DocumentId val id: String = "",
  val userId: String = "",
  val date: String = "",
  val timestamp: Long = System.currentTimeMillis(),
  val type: String = "sale", // "sale", "credit_sale", "collection", "purchase", "supplier_payment", "expense", "transfer", "other"
  val amount: Double = 0.0,
  val paidAmount: Double = 0.0,
  val dueAmount: Double = 0.0,
  val method: String = "cash", // "cash", "bkash", "nagad", "bank", "credit"
  val accountId: String = "cash",
  val targetAccountId: String? = null,
  val note: String = "",
  val customerId: String? = null,
  val customerName: String? = null,
  val supplierId: String? = null,
  val supplierName: String? = null,
  val profit: Double? = null,
  val items: List<CartItem> = emptyList()
)

@IgnoreExtraProperties
data class ShopInfo(
  @DocumentId val id: String = "shop_info",
  val userId: String = "",
  val name: String = "আমার মুদি দোকান",
  val phone: String = "",
  val address: String = ""
)

object DokanFormatter {
  fun formatMoney(amount: Double): String {
    val formatter = NumberFormat.getNumberInstance(Locale("bn", "BD")).apply {
      maximumFractionDigits = 2
      minimumFractionDigits = 0
    }
    return "৳" + formatter.format(amount)
  }

  fun formatMoneySimple(amount: Double): String {
    return String.format(Locale.US, "৳%.2f", amount).replace(".00", "")
  }

  fun typeLabel(type: String): String = when (type) {
    "sale" -> "নগদ বিক্রি"
    "credit_sale" -> "বাকি বিক্রি"
    "collection" -> "বাকি আদায়"
    "purchase" -> "পণ্য ক্রয় (মহাজন)"
    "supplier_payment" -> "মহাজন পরিশোধ"
    "expense" -> "দোকানের খরচ"
    "transfer" -> "টাকা স্থানান্তর"
    "other" -> "অন্যান্য লেনদেন"
    else -> type
  }

  fun methodLabel(method: String): String = when (method) {
    "cash" -> "নগদ ক্যাশ"
    "bkash" -> "বিকাশ"
    "nagad" -> "নগদ অ্যাপ"
    "bank" -> "ব্যাংক"
    "credit" -> "বাকি"
    else -> method
  }

  fun accountName(accountId: String): String = when (accountId) {
    "cash" -> "নগদ ক্যাশ বাক্স"
    "bkash" -> "বিকাশ ব্যালেন্স"
    "nagad" -> "নগদ ব্যালেন্স"
    "bank" -> "ব্যাংক একাউন্ট"
    else -> accountId
  }
}
