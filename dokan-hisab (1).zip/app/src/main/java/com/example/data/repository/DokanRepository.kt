package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.CustomerEntity
import com.example.data.local.ProductEntity
import com.example.data.local.ShopEntity
import com.example.data.local.TransactionEntity
import com.example.data.model.CartItem
import com.example.data.model.Customer
import com.example.data.model.Product
import com.example.data.model.Transaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class DokanRepository(private val db: AppDatabase) {
  private val productDao = db.productDao()
  private val customerDao = db.customerDao()
  private val transactionDao = db.transactionDao()
  private val shopDao = db.shopDao()

  val productsFlow: Flow<List<Product>> = productDao.getAllProductsFlow().map { list ->
    list.map { it.toModel() }
  }

  val customersFlow: Flow<List<Customer>> = customerDao.getAllCustomersFlow().map { list ->
    list.map { it.toModel() }
  }

  val transactionsFlow: Flow<List<Transaction>> = transactionDao.getAllTransactionsFlow().map { list ->
    list.map { it.toModel() }
  }

  val recentTransactionsFlow: Flow<List<Transaction>> = transactionDao.getRecentTransactionsFlow(12).map { list ->
    list.map { it.toModel() }
  }

  val shopNameFlow: Flow<String> = shopDao.getShopFlow().map {
    it?.name ?: "আমার মুদি দোকান"
  }

  private fun getTodayDateString(): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    return sdf.format(Date())
  }

  suspend fun addProduct(name: String, buy: Double, sell: Double, stock: Double, unit: String) = withContext(Dispatchers.IO) {
    val entity = ProductEntity(
      id = UUID.randomUUID().toString(),
      name = name.trim(),
      buy = buy,
      sell = sell,
      stock = stock,
      unit = unit.trim().ifEmpty { "টি" }
    )
    productDao.insertProduct(entity)
  }

  suspend fun updateProduct(id: String, name: String, buy: Double, sell: Double, stock: Double, unit: String) = withContext(Dispatchers.IO) {
    val entity = ProductEntity(
      id = id,
      name = name.trim(),
      buy = buy,
      sell = sell,
      stock = stock,
      unit = unit.trim().ifEmpty { "টি" }
    )
    productDao.updateProduct(entity)
  }

  suspend fun addStock(id: String, additionalStock: Double) = withContext(Dispatchers.IO) {
    productDao.addStock(id, additionalStock)
  }

  suspend fun deleteProduct(id: String) = withContext(Dispatchers.IO) {
    productDao.deleteProductById(id)
  }

  suspend fun addCustomer(name: String, phone: String, opening: Double) = withContext(Dispatchers.IO) {
    val entity = CustomerEntity(
      id = UUID.randomUUID().toString(),
      name = name.trim(),
      phone = phone.trim(),
      opening = if (opening < 0) 0.0 else opening
    )
    customerDao.insertCustomer(entity)
  }

  suspend fun updateCustomer(id: String, name: String, phone: String, opening: Double) = withContext(Dispatchers.IO) {
    val entity = CustomerEntity(
      id = id,
      name = name.trim(),
      phone = phone.trim(),
      opening = if (opening < 0) 0.0 else opening
    )
    customerDao.updateCustomer(entity)
  }

  suspend fun deleteCustomer(id: String) = withContext(Dispatchers.IO) {
    customerDao.deleteCustomerById(id)
  }

  suspend fun addSale(
    productId: String,
    qty: Double,
    method: String,
    customerId: String?
  ): Result<Unit> = withContext(Dispatchers.IO) {
    val product = productDao.getProductById(productId)
      ?: return@withContext Result.failure(Exception("পণ্য পাওয়া যায়নি"))

    if (qty <= 0) {
      return@withContext Result.failure(Exception("সঠিক পরিমাণ লিখুন"))
    }

    if (qty > product.stock) {
      return@withContext Result.failure(Exception("স্টকে পর্যাপ্ত পণ্য নেই (বর্তমান স্টক: ${product.stock} ${product.unit})"))
    }

    if (method == "credit" && customerId.isNullOrBlank()) {
      return@withContext Result.failure(Exception("বাকির জন্য কাস্টমার নির্বাচন করুন"))
    }

    val amount = qty * product.sell
    val profit = qty * (product.sell - product.buy)
    val isCredit = method == "credit"

    val tx = TransactionEntity(
      id = UUID.randomUUID().toString(),
      date = getTodayDateString(),
      timestamp = System.currentTimeMillis(),
      type = if (isCredit) "credit" else "sale",
      amount = amount,
      method = method,
      note = "${product.name} × $qty ${product.unit}",
      customerId = if (isCredit) customerId else null,
      profit = profit,
      productId = product.id,
      productName = product.name,
      itemQty = qty,
      itemBuyPrice = product.buy,
      itemSellPrice = product.sell
    )

    // Atomic update
    productDao.deductStock(product.id, qty)
    transactionDao.insertTransaction(tx)

    Result.success(Unit)
  }

  suspend fun addCollection(
    customerId: String,
    amount: Double,
    method: String
  ): Result<Unit> = withContext(Dispatchers.IO) {
    if (amount <= 0) {
      return@withContext Result.failure(Exception("সঠিক টাকার পরিমাণ দিন"))
    }

    val customer = customerDao.getCustomerById(customerId)
      ?: return@withContext Result.failure(Exception("কাস্টমার পাওয়া যায়নি"))

    val tx = TransactionEntity(
      id = UUID.randomUUID().toString(),
      date = getTodayDateString(),
      timestamp = System.currentTimeMillis(),
      type = "collection",
      amount = amount,
      method = method,
      note = "কাস্টমারের বাকি আদায় (${customer.name})",
      customerId = customerId,
      profit = 0.0
    )

    transactionDao.insertTransaction(tx)
    Result.success(Unit)
  }

  suspend fun addExpense(
    note: String,
    amount: Double,
    method: String
  ): Result<Unit> = withContext(Dispatchers.IO) {
    if (amount <= 0 || note.isBlank()) {
      return@withContext Result.failure(Exception("খরচের বিবরণ ও সঠিক টাকা দিন"))
    }

    val tx = TransactionEntity(
      id = UUID.randomUUID().toString(),
      date = getTodayDateString(),
      timestamp = System.currentTimeMillis(),
      type = "expense",
      amount = amount,
      method = method,
      note = note.trim(),
      customerId = null,
      profit = -amount
    )

    transactionDao.insertTransaction(tx)
    Result.success(Unit)
  }

  suspend fun addOtherTransaction(
    direction: String,
    note: String,
    amount: Double,
    method: String
  ): Result<Unit> = withContext(Dispatchers.IO) {
    if (amount <= 0 || note.isBlank()) {
      return@withContext Result.failure(Exception("বিবরণ ও সঠিক টাকা দিন"))
    }

    val tx = TransactionEntity(
      id = UUID.randomUUID().toString(),
      date = getTodayDateString(),
      timestamp = System.currentTimeMillis(),
      type = "other",
      amount = amount,
      method = method,
      note = "$direction: ${note.trim()}",
      customerId = null,
      profit = 0.0
    )

    transactionDao.insertTransaction(tx)
    Result.success(Unit)
  }

  suspend fun updateShopName(name: String) = withContext(Dispatchers.IO) {
    shopDao.setShop(ShopEntity(id = 1, name = name.trim()))
  }

  suspend fun deleteTransaction(id: String) = withContext(Dispatchers.IO) {
    transactionDao.deleteTransactionById(id)
  }

  fun getCustomerDue(
    customer: Customer,
    transactions: List<Transaction>
  ): Double {
    val credits = transactions.filter { it.customerId == customer.id && it.type == "credit" }.sumOf { it.amount }
    val collections = transactions.filter { it.customerId == customer.id && it.type == "collection" }.sumOf { it.amount }
    return customer.opening + credits - collections
  }

  suspend fun exportBackupJson(): String = withContext(Dispatchers.IO) {
    val shop = shopDao.getShop()?.name ?: "আমার মুদি দোকান"
    val products = productDao.getAllProductsFlow().firstOrNull() ?: emptyList()
    val customers = customerDao.getAllCustomersFlow().firstOrNull() ?: emptyList()
    val transactions = transactionDao.getAllTransactionsFlow().firstOrNull() ?: emptyList()

    val root = JSONObject()
    root.put("shop", shop)

    val prodArray = JSONArray()
    for (p in products) {
      val o = JSONObject()
      o.put("id", p.id)
      o.put("name", p.name)
      o.put("buy", p.buy)
      o.put("sell", p.sell)
      o.put("stock", p.stock)
      o.put("unit", p.unit)
      prodArray.put(o)
    }
    root.put("products", prodArray)

    val custArray = JSONArray()
    for (c in customers) {
      val o = JSONObject()
      o.put("id", c.id)
      o.put("name", c.name)
      o.put("phone", c.phone)
      o.put("opening", c.opening)
      custArray.put(o)
    }
    root.put("customers", custArray)

    val txArray = JSONArray()
    for (t in transactions) {
      val o = JSONObject()
      o.put("id", t.id)
      o.put("date", t.date)
      o.put("type", t.type)
      o.put("amount", t.amount)
      o.put("method", t.method)
      o.put("note", t.note)
      if (t.customerId != null) o.put("customerId", t.customerId)
      if (t.profit != null) o.put("profit", t.profit)
      txArray.put(o)
    }
    root.put("transactions", txArray)

    root.toString(2)
  }

  suspend fun importBackupJson(jsonString: String): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val root = JSONObject(jsonString)
      val shopName = root.optString("shop", "আমার মুদি দোকান")

      val prodArray = root.getJSONArray("products")
      val newProducts = mutableListOf<ProductEntity>()
      for (i in 0 until prodArray.length()) {
        val o = prodArray.getJSONObject(i)
        newProducts.add(
          ProductEntity(
            id = o.optString("id", UUID.randomUUID().toString()),
            name = o.getString("name"),
            buy = o.getDouble("buy"),
            sell = o.getDouble("sell"),
            stock = o.getDouble("stock"),
            unit = o.optString("unit", "টি")
          )
        )
      }

      val custArray = root.getJSONArray("customers")
      val newCustomers = mutableListOf<CustomerEntity>()
      for (i in 0 until custArray.length()) {
        val o = custArray.getJSONObject(i)
        newCustomers.add(
          CustomerEntity(
            id = o.optString("id", UUID.randomUUID().toString()),
            name = o.getString("name"),
            phone = o.optString("phone", ""),
            opening = o.optDouble("opening", 0.0)
          )
        )
      }

      val txArray = root.getJSONArray("transactions")
      val newTxs = mutableListOf<TransactionEntity>()
      for (i in 0 until txArray.length()) {
        val o = txArray.getJSONObject(i)
        newTxs.add(
          TransactionEntity(
            id = o.optString("id", UUID.randomUUID().toString()),
            date = o.optString("date", getTodayDateString()),
            timestamp = System.currentTimeMillis() - (txArray.length() - i) * 60000L,
            type = o.getString("type"),
            amount = o.getDouble("amount"),
            method = o.optString("method", "cash"),
            note = o.optString("note", ""),
            customerId = if (o.has("customerId")) o.getString("customerId") else null,
            profit = if (o.has("profit")) o.getDouble("profit") else null
          )
        )
      }

      // Replace in DB
      productDao.clearAll()
      customerDao.clearAll()
      transactionDao.clearAll()

      shopDao.setShop(ShopEntity(id = 1, name = shopName))
      productDao.insertAll(newProducts)
      customerDao.insertAll(newCustomers)
      transactionDao.insertAll(newTxs)

      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun seedInitialDataIfEmpty() = withContext(Dispatchers.IO) {
    val existingProducts = productDao.getAllProductsFlow().firstOrNull() ?: emptyList()
    if (existingProducts.isNotEmpty()) return@withContext

    shopDao.setShop(ShopEntity(id = 1, name = "মেসার্স ভাই ভাই স্টোর"))

    val initialProducts = listOf(
      ProductEntity(id = UUID.randomUUID().toString(), name = "রূপচাঁদা সয়াবিন তেল (৫ লিটার)", buy = 780.0, sell = 860.0, stock = 12.0, unit = "বোতল"),
      ProductEntity(id = UUID.randomUUID().toString(), name = "তীর চিনি (১ কেজি)", buy = 125.0, sell = 135.0, stock = 45.0, unit = "কেজি"),
      ProductEntity(id = UUID.randomUUID().toString(), name = "মিনিকেট চাল (৫০ কেজি)", buy = 3200.0, sell = 3450.0, stock = 8.0, unit = "বস্তা"),
      ProductEntity(id = UUID.randomUUID().toString(), name = "দেশি মসুর ডাল", buy = 130.0, sell = 150.0, stock = 3.0, unit = "কেজি"), // low stock!
      ProductEntity(id = UUID.randomUUID().toString(), name = "লাক্স সাবান (১০০ গ্রাম)", buy = 52.0, sell = 60.0, stock = 30.0, unit = "টি"),
      ProductEntity(id = UUID.randomUUID().toString(), name = "প্রাণ গুঁড়া দুধ (৫০০ গ্রাম)", buy = 380.0, sell = 420.0, stock = 4.0, unit = "প্যাকেট"), // low stock!
      ProductEntity(id = UUID.randomUUID().toString(), name = "ডিম (১ ডজন)", buy = 130.0, sell = 145.0, stock = 15.0, unit = "ডজন")
    )
    productDao.insertAll(initialProducts)

    val c1Id = UUID.randomUUID().toString()
    val c2Id = UUID.randomUUID().toString()
    val c3Id = UUID.randomUUID().toString()

    val initialCustomers = listOf(
      CustomerEntity(id = c1Id, name = "আব্দুর রহিম (মাস্টার সাহেব)", phone = "01711234567", opening = 500.0),
      CustomerEntity(id = c2Id, name = "মোবারক হোসেন (ড্রাইভার)", phone = "01819876543", opening = 1200.0),
      CustomerEntity(id = c3Id, name = "কামাল হোসেন (দোকানি)", phone = "01912345678", opening = 0.0)
    )
    customerDao.insertAll(initialCustomers)

    val today = getTodayDateString()
    val now = System.currentTimeMillis()

    val initialTransactions = listOf(
      TransactionEntity(
        id = UUID.randomUUID().toString(),
        date = today,
        timestamp = now - 3600000 * 4,
        type = "sale",
        amount = 860.0,
        method = "cash",
        note = "রূপচাঁদা সয়াবিন তেল × 1 বোতল",
        customerId = null,
        profit = 80.0
      ),
      TransactionEntity(
        id = UUID.randomUUID().toString(),
        date = today,
        timestamp = now - 3600000 * 3,
        type = "credit",
        amount = 270.0,
        method = "credit",
        note = "তীর চিনি × 2 কেজি",
        customerId = c1Id,
        profit = 20.0
      ),
      TransactionEntity(
        id = UUID.randomUUID().toString(),
        date = today,
        timestamp = now - 3600000 * 2,
        type = "collection",
        amount = 500.0,
        method = "bkash",
        note = "কাস্টমারের বাকি আদায় (মোবারক হোসেন)",
        customerId = c2Id,
        profit = 0.0
      ),
      TransactionEntity(
        id = UUID.randomUUID().toString(),
        date = today,
        timestamp = now - 3600000,
        type = "expense",
        amount = 80.0,
        method = "cash",
        note = "দোকানের চা-নাস্তা খরচ",
        customerId = null,
        profit = -80.0
      )
    )
    transactionDao.insertAll(initialTransactions)
  }
}
