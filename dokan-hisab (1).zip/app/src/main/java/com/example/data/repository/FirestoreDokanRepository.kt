package com.example.data.repository

import com.example.data.model.Account
import com.example.data.model.CartItem
import com.example.data.model.Customer
import com.example.data.model.Product
import com.example.data.model.ShopInfo
import com.example.data.model.Supplier
import com.example.data.model.Transaction
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class FirestoreDokanRepository(
  val db: FirebaseFirestore,
  val auth: FirebaseAuth
) {
  fun requireUserId(): String {
    return auth.currentUser?.uid
      ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
  }

  private fun getTodayDateString(): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    return sdf.format(Date())
  }

  // --- Real-time Observers ---

  fun observeProducts(): Flow<List<Product>> = flow {
    val uid = requireUserId()
    db.collection("users").document(uid).collection("products")
      .snapshots()
      .map { snapshot -> snapshot.toObjects(Product::class.java) }
      .collect { emit(it) }
  }

  fun observeCustomers(): Flow<List<Customer>> = flow {
    val uid = requireUserId()
    db.collection("users").document(uid).collection("customers")
      .snapshots()
      .map { snapshot -> snapshot.toObjects(Customer::class.java) }
      .collect { emit(it) }
  }

  fun observeSuppliers(): Flow<List<Supplier>> = flow {
    val uid = requireUserId()
    db.collection("users").document(uid).collection("suppliers")
      .snapshots()
      .map { snapshot -> snapshot.toObjects(Supplier::class.java) }
      .collect { emit(it) }
  }

  fun observeAccounts(): Flow<List<Account>> = flow {
    val uid = requireUserId()
    db.collection("users").document(uid).collection("accounts")
      .snapshots()
      .map { snapshot -> snapshot.toObjects(Account::class.java) }
      .collect { emit(it) }
  }

  fun observeTransactions(): Flow<List<Transaction>> = flow {
    val uid = requireUserId()
    db.collection("users").document(uid).collection("transactions")
      .snapshots()
      .map { snapshot ->
        snapshot.toObjects(Transaction::class.java)
          .sortedByDescending { it.timestamp }
      }
      .collect { emit(it) }
  }

  fun observeShopInfo(): Flow<ShopInfo?> = flow {
    val uid = requireUserId()
    db.collection("users").document(uid).collection("shop_info").document("shop_info")
      .snapshots()
      .map { snapshot -> snapshot.toObject(ShopInfo::class.java) }
      .collect { emit(it) }
  }

  // --- Business Workflows ---

  suspend fun recordSale(
    items: List<CartItem>,
    method: String,
    accountId: String,
    customerId: String?,
    customerName: String?,
    paidAmount: Double,
    note: String
  ): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val uid = requireUserId()
      require(items.isNotEmpty()) { "বিক্রির জন্য অন্তত একটি পণ্য যোগ করুন" }

      val totalAmount = items.sumOf { it.total }
      val totalCost = items.sumOf { it.qty * it.buyPrice }
      val profit = totalAmount - totalCost
      val dueAmount = (totalAmount - paidAmount).coerceAtLeast(0.0)
      val txType = if (dueAmount > 0 && paidAmount <= 0) "credit_sale" else "sale"

      val txId = UUID.randomUUID().toString()
      val userRef = db.collection("users").document(uid)
      val txRef = userRef.collection("transactions").document(txId)
      val accountRef = userRef.collection("accounts").document(accountId)

      val itemsSummary = items.joinToString(", ") { "${it.name} × ${it.qty} ${it.unit}" }
      val finalNote = if (note.isNotBlank()) note else itemsSummary

      db.runTransaction { transaction ->
        // 1. ALL READS FIRST: Read products and account
        val prodUpdates = items.map { item ->
          val prodRef = userRef.collection("products").document(item.productId)
          val prodDoc = transaction.get(prodRef)
          val currentStock = prodDoc.getDouble("stock") ?: 0.0
          val newStock = (currentStock - item.qty).coerceAtLeast(0.0)
          prodRef to newStock
        }

        val newAccBalance = if (paidAmount > 0) {
          val accDoc = transaction.get(accountRef)
          if (accDoc.exists()) {
            val currentBalance = accDoc.getDouble("balance") ?: 0.0
            currentBalance + paidAmount
          } else null
        } else null

        // 2. ALL WRITES SECOND: Update products and account
        for ((prodRef, newStock) in prodUpdates) {
          transaction.update(prodRef, "stock", newStock)
        }

        if (newAccBalance != null) {
          transaction.update(accountRef, "balance", newAccBalance)
        }

        // 3. Write transaction record
        val txData = hashMapOf(
          "id" to txId,
          "userId" to uid,
          "date" to getTodayDateString(),
          "timestamp" to System.currentTimeMillis(),
          "type" to txType,
          "amount" to totalAmount,
          "paidAmount" to paidAmount,
          "dueAmount" to dueAmount,
          "method" to method,
          "accountId" to accountId,
          "note" to finalNote,
          "customerId" to customerId,
          "customerName" to customerName,
          "profit" to profit,
          "items" to items.map {
            mapOf(
              "productId" to it.productId,
              "name" to it.name,
              "qty" to it.qty,
              "unit" to it.unit,
              "buyPrice" to it.buyPrice,
              "sellPrice" to it.sellPrice,
              "total" to it.total
            )
          }
        ).filterValues { it != null }
        transaction.set(txRef, txData)
      }.await()

      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun recordPurchase(
    supplierId: String?,
    supplierName: String?,
    items: List<CartItem>,
    paidAmount: Double,
    accountId: String,
    method: String,
    note: String
  ): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val uid = requireUserId()
      require(items.isNotEmpty()) { "ক্রয়ের জন্য অন্তত একটি পণ্য নির্বাচন করুন" }

      val totalAmount = items.sumOf { it.total }
      val dueAmount = (totalAmount - paidAmount).coerceAtLeast(0.0)

      val txId = UUID.randomUUID().toString()
      val userRef = db.collection("users").document(uid)
      val txRef = userRef.collection("transactions").document(txId)
      val accountRef = userRef.collection("accounts").document(accountId)

      val itemsSummary = items.joinToString(", ") { "${it.name} +${it.qty} ${it.unit}" }
      val finalNote = if (note.isNotBlank()) note else "মহাজন মাল ক্রয়: $itemsSummary"

      db.runTransaction { transaction ->
        // 1. ALL READS FIRST: Read products and account
        val prodUpdates = items.map { item ->
          val prodRef = userRef.collection("products").document(item.productId)
          val prodDoc = transaction.get(prodRef)
          val currentStock = if (prodDoc.exists()) prodDoc.getDouble("stock") ?: 0.0 else 0.0
          val currentSell = if (prodDoc.exists()) prodDoc.getDouble("sell") ?: 0.0 else 0.0
          val updateMap = mapOf(
            "stock" to (currentStock + item.qty),
            "buy" to item.buyPrice,
            "sell" to if (item.sellPrice > 0) item.sellPrice else currentSell
          )
          prodRef to updateMap
        }

        val newAccBalance = if (paidAmount > 0) {
          val accDoc = transaction.get(accountRef)
          if (accDoc.exists()) {
            val currentBal = accDoc.getDouble("balance") ?: 0.0
            currentBal - paidAmount
          } else null
        } else null

        // 2. ALL WRITES SECOND: Update products and account
        for ((prodRef, updateMap) in prodUpdates) {
          transaction.update(prodRef, updateMap)
        }

        if (newAccBalance != null) {
          transaction.update(accountRef, "balance", newAccBalance)
        }

        // 3. Write transaction
        val txData = hashMapOf(
          "id" to txId,
          "userId" to uid,
          "date" to getTodayDateString(),
          "timestamp" to System.currentTimeMillis(),
          "type" to "purchase",
          "amount" to totalAmount,
          "paidAmount" to paidAmount,
          "dueAmount" to dueAmount,
          "method" to method,
          "accountId" to accountId,
          "note" to finalNote,
          "supplierId" to supplierId,
          "supplierName" to supplierName,
          "profit" to 0.0,
          "items" to items.map {
            mapOf(
              "productId" to it.productId,
              "name" to it.name,
              "qty" to it.qty,
              "unit" to it.unit,
              "buyPrice" to it.buyPrice,
              "sellPrice" to it.sellPrice,
              "total" to it.total
            )
          }
        ).filterValues { it != null }
        transaction.set(txRef, txData)
      }.await()

      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun recordCustomerCollection(
    customerId: String,
    customerName: String,
    amount: Double,
    accountId: String,
    method: String,
    note: String
  ): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val uid = requireUserId()
      require(amount > 0) { "সঠিক টাকার পরিমাণ দিন" }

      val txId = UUID.randomUUID().toString()
      val userRef = db.collection("users").document(uid)
      val txRef = userRef.collection("transactions").document(txId)
      val accountRef = userRef.collection("accounts").document(accountId)

      db.runTransaction { transaction ->
        val accDoc = transaction.get(accountRef)
        if (accDoc.exists()) {
          val currentBal = accDoc.getDouble("balance") ?: 0.0
          transaction.update(accountRef, "balance", currentBal + amount)
        }

        val txData = hashMapOf(
          "id" to txId,
          "userId" to uid,
          "date" to getTodayDateString(),
          "timestamp" to System.currentTimeMillis(),
          "type" to "collection",
          "amount" to amount,
          "paidAmount" to amount,
          "dueAmount" to 0.0,
          "method" to method,
          "accountId" to accountId,
          "note" to if (note.isNotBlank()) note else "কাস্টমারের বাকি আদায় ($customerName)",
          "customerId" to customerId,
          "customerName" to customerName,
          "profit" to 0.0
        )
        transaction.set(txRef, txData)
      }.await()

      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun recordSupplierPayment(
    supplierId: String,
    supplierName: String,
    amount: Double,
    accountId: String,
    method: String,
    note: String
  ): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val uid = requireUserId()
      require(amount > 0) { "সঠিক টাকার পরিমাণ দিন" }

      val txId = UUID.randomUUID().toString()
      val userRef = db.collection("users").document(uid)
      val txRef = userRef.collection("transactions").document(txId)
      val accountRef = userRef.collection("accounts").document(accountId)

      db.runTransaction { transaction ->
        val accDoc = transaction.get(accountRef)
        if (accDoc.exists()) {
          val currentBal = accDoc.getDouble("balance") ?: 0.0
          transaction.update(accountRef, "balance", currentBal - amount)
        }

        val txData = hashMapOf(
          "id" to txId,
          "userId" to uid,
          "date" to getTodayDateString(),
          "timestamp" to System.currentTimeMillis(),
          "type" to "supplier_payment",
          "amount" to amount,
          "paidAmount" to amount,
          "dueAmount" to 0.0,
          "method" to method,
          "accountId" to accountId,
          "note" to if (note.isNotBlank()) note else "মহাজন দেনা পরিশোধ ($supplierName)",
          "supplierId" to supplierId,
          "supplierName" to supplierName,
          "profit" to 0.0
        )
        transaction.set(txRef, txData)
      }.await()

      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun recordExpense(
    note: String,
    amount: Double,
    accountId: String,
    method: String
  ): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val uid = requireUserId()
      require(note.isNotBlank() && amount > 0) { "খরচের বিবরণ ও সঠিক টাকা দিন" }

      val txId = UUID.randomUUID().toString()
      val userRef = db.collection("users").document(uid)
      val txRef = userRef.collection("transactions").document(txId)
      val accountRef = userRef.collection("accounts").document(accountId)

      db.runTransaction { transaction ->
        val accDoc = transaction.get(accountRef)
        if (accDoc.exists()) {
          val currentBal = accDoc.getDouble("balance") ?: 0.0
          transaction.update(accountRef, "balance", currentBal - amount)
        }

        val txData = hashMapOf(
          "id" to txId,
          "userId" to uid,
          "date" to getTodayDateString(),
          "timestamp" to System.currentTimeMillis(),
          "type" to "expense",
          "amount" to amount,
          "paidAmount" to amount,
          "dueAmount" to 0.0,
          "method" to method,
          "accountId" to accountId,
          "note" to note.trim(),
          "profit" to -amount
        )
        transaction.set(txRef, txData)
      }.await()

      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun recordTransfer(
    fromAccountId: String,
    toAccountId: String,
    amount: Double,
    note: String
  ): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val uid = requireUserId()
      require(fromAccountId != toAccountId) { "একই একাউন্টে স্থানান্তর করা যাবে না" }
      require(amount > 0) { "সঠিক পরিমাণ দিন" }

      val txId = UUID.randomUUID().toString()
      val userRef = db.collection("users").document(uid)
      val txRef = userRef.collection("transactions").document(txId)
      val fromRef = userRef.collection("accounts").document(fromAccountId)
      val toRef = userRef.collection("accounts").document(toAccountId)

      db.runTransaction { transaction ->
        val fromDoc = transaction.get(fromRef)
        val toDoc = transaction.get(toRef)

        val fromBal = fromDoc.getDouble("balance") ?: 0.0
        val toBal = toDoc.getDouble("balance") ?: 0.0

        transaction.update(fromRef, "balance", fromBal - amount)
        transaction.update(toRef, "balance", toBal + amount)

        val txData = hashMapOf(
          "id" to txId,
          "userId" to uid,
          "date" to getTodayDateString(),
          "timestamp" to System.currentTimeMillis(),
          "type" to "transfer",
          "amount" to amount,
          "paidAmount" to amount,
          "dueAmount" to 0.0,
          "method" to "transfer",
          "accountId" to fromAccountId,
          "targetAccountId" to toAccountId,
          "note" to if (note.isNotBlank()) note else "$fromAccountId থেকে $toAccountId এ স্থানান্তর"
        )
        transaction.set(txRef, txData)
      }.await()

      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun recordOtherTransaction(
    direction: String,
    note: String,
    amount: Double,
    accountId: String,
    method: String
  ): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val uid = requireUserId()
      require(note.isNotBlank() && amount > 0) { "বিবরণ ও সঠিক টাকা দিন" }

      val txId = UUID.randomUUID().toString()
      val userRef = db.collection("users").document(uid)
      val txRef = userRef.collection("transactions").document(txId)
      val accountRef = userRef.collection("accounts").document(accountId)
      val isIncome = direction == "টাকা গ্রহণ"

      db.runTransaction { transaction ->
        val accDoc = transaction.get(accountRef)
        if (accDoc.exists()) {
          val currentBal = accDoc.getDouble("balance") ?: 0.0
          val newBal = if (isIncome) currentBal + amount else currentBal - amount
          transaction.update(accountRef, "balance", newBal)
        }

        val txData = hashMapOf(
          "id" to txId,
          "userId" to uid,
          "date" to getTodayDateString(),
          "timestamp" to System.currentTimeMillis(),
          "type" to "other",
          "amount" to amount,
          "paidAmount" to amount,
          "dueAmount" to 0.0,
          "method" to method,
          "accountId" to accountId,
          "note" to "$direction: ${note.trim()}",
          "profit" to if (isIncome) amount else -amount
        )
        transaction.set(txRef, txData)
      }.await()

      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  // --- Entity CRUD Operations ---

  suspend fun saveProduct(product: Product): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val uid = requireUserId()
      val id = if (product.id.isNotBlank()) product.id else UUID.randomUUID().toString()
      val map = hashMapOf(
        "id" to id,
        "userId" to uid,
        "name" to product.name.trim(),
        "buy" to product.buy,
        "sell" to product.sell,
        "stock" to product.stock,
        "unit" to product.unit.trim().ifEmpty { "টি" }
      )
      db.collection("users").document(uid).collection("products").document(id)
        .set(map)
        .await()
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun deleteProduct(id: String): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val uid = requireUserId()
      db.collection("users").document(uid).collection("products").document(id)
        .delete()
        .await()
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun saveCustomer(customer: Customer): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val uid = requireUserId()
      val id = if (customer.id.isNotBlank()) customer.id else UUID.randomUUID().toString()
      val map = hashMapOf(
        "id" to id,
        "userId" to uid,
        "name" to customer.name.trim(),
        "phone" to customer.phone.trim(),
        "opening" to customer.opening
      )
      db.collection("users").document(uid).collection("customers").document(id)
        .set(map)
        .await()
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun deleteCustomer(id: String): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val uid = requireUserId()
      db.collection("users").document(uid).collection("customers").document(id)
        .delete()
        .await()
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun saveSupplier(supplier: Supplier): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val uid = requireUserId()
      val id = if (supplier.id.isNotBlank()) supplier.id else UUID.randomUUID().toString()
      val map = hashMapOf(
        "id" to id,
        "userId" to uid,
        "name" to supplier.name.trim(),
        "company" to supplier.company.trim(),
        "phone" to supplier.phone.trim(),
        "opening" to supplier.opening
      )
      db.collection("users").document(uid).collection("suppliers").document(id)
        .set(map)
        .await()
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun deleteSupplier(id: String): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val uid = requireUserId()
      db.collection("users").document(uid).collection("suppliers").document(id)
        .delete()
        .await()
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun updateShopInfo(name: String, phone: String = "", address: String = ""): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val uid = requireUserId()
      val map = hashMapOf(
        "id" to "shop_info",
        "userId" to uid,
        "name" to name.trim(),
        "phone" to phone.trim(),
        "address" to address.trim()
      )
      db.collection("users").document(uid).collection("shop_info").document("shop_info")
        .set(map)
        .await()
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun updateAccountBalance(accountId: String, newBalance: Double): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val uid = requireUserId()
      db.collection("users").document(uid).collection("accounts").document(accountId)
        .update("balance", newBalance)
        .await()
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun deleteTransaction(id: String): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val uid = requireUserId()
      db.collection("users").document(uid).collection("transactions").document(id)
        .delete()
        .await()
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  // --- Seed Initial Accounts & Products ---

  suspend fun seedInitialDataIfEmpty(): Unit = withContext(Dispatchers.IO) {
    try {
      val uid = requireUserId()
      val userRef = db.collection("users").document(uid)

      // 1. Initialize Default Accounts if not present
      val accountsSnapshot = userRef.collection("accounts").get().await()
      if (accountsSnapshot.isEmpty) {
        val defaultAccounts = listOf(
          Account(id = "cash", userId = uid, name = "নগদ ক্যাশ বাক্স", balance = 5000.0, type = "cash"),
          Account(id = "bkash", userId = uid, name = "বিকাশ মার্চেন্ট / পার্সোনাল", balance = 2500.0, type = "mobile_banking"),
          Account(id = "nagad", userId = uid, name = "নগদ একাউন্ট", balance = 1200.0, type = "mobile_banking"),
          Account(id = "bank", userId = uid, name = "ব্যাংক একাউন্ট", balance = 25000.0, type = "bank")
        )
        for (acc in defaultAccounts) {
          userRef.collection("accounts").document(acc.id).set(acc).await()
        }
      }

      // 2. Initialize Shop Info if not present
      val shopDoc = userRef.collection("shop_info").document("shop_info").get().await()
      if (!shopDoc.exists()) {
        userRef.collection("shop_info").document("shop_info").set(
          ShopInfo(id = "shop_info", userId = uid, name = "মেসার্স ভাই ভাই স্টোর", phone = "01711223344", address = "বাজার রোড, ঢাকা")
        ).await()
      }

      // 3. Initialize Products if empty
      val prodsSnapshot = userRef.collection("products").get().await()
      if (prodsSnapshot.isEmpty) {
        val defaultProducts = listOf(
          Product(id = "p1", userId = uid, name = "রূপচাঁদা সয়াবিন তেল (৫ লিটার)", buy = 780.0, sell = 860.0, stock = 15.0, unit = "বোতল"),
          Product(id = "p2", userId = uid, name = "তীর চিনি (১ কেজি)", buy = 125.0, sell = 135.0, stock = 50.0, unit = "কেজি"),
          Product(id = "p3", userId = uid, name = "মিনিকেট চাল (৫০ কেজি)", buy = 3200.0, sell = 3450.0, stock = 12.0, unit = "বস্তা"),
          Product(id = "p4", userId = uid, name = "দেশি মসুর ডাল", buy = 130.0, sell = 150.0, stock = 4.0, unit = "কেজি"),
          Product(id = "p5", userId = uid, name = "লাক্স সাবান (১০০ গ্রাম)", buy = 52.0, sell = 60.0, stock = 35.0, unit = "টি"),
          Product(id = "p6", userId = uid, name = "প্রাণ গুঁড়া দুধ (৫০০ গ্রাম)", buy = 380.0, sell = 420.0, stock = 3.0, unit = "প্যাকেট"),
          Product(id = "p7", userId = uid, name = "তাজা ডিম (১ ডজন)", buy = 130.0, sell = 145.0, stock = 20.0, unit = "ডজন")
        )
        for (p in defaultProducts) {
          userRef.collection("products").document(p.id).set(p).await()
        }
      }

      // 4. Initialize Suppliers if empty
      val suppSnapshot = userRef.collection("suppliers").get().await()
      if (suppSnapshot.isEmpty) {
        val defaultSuppliers = listOf(
          Supplier(id = "s1", userId = uid, name = "মোশাররফ হোসেন", company = "মেঘনা গ্রুপ ডিলার", phone = "01811223344", opening = 15000.0),
          Supplier(id = "s2", userId = uid, name = "আবুল কাশেম", company = "সিটি গ্রুপ (তীর)", phone = "01911223344", opening = 8500.0)
        )
        for (s in defaultSuppliers) {
          userRef.collection("suppliers").document(s.id).set(s).await()
        }
      }

      // 5. Initialize Customers if empty
      val custSnapshot = userRef.collection("customers").get().await()
      if (custSnapshot.isEmpty) {
        val defaultCustomers = listOf(
          Customer(id = "c1", userId = uid, name = "আব্দুর রহিম (মাস্টার সাহেব)", phone = "01711234567", opening = 1250.0),
          Customer(id = "c2", userId = uid, name = "মোবারক হোসেন (ড্রাইভার)", phone = "01819876543", opening = 800.0),
          Customer(id = "c3", userId = uid, name = "কামাল হোসেন", phone = "01912345678", opening = 0.0)
        )
        for (c in defaultCustomers) {
          userRef.collection("customers").document(c.id).set(c).await()
        }
      }
    } catch (_: Exception) {
      // Best-effort initial seeding
    }
  }
}
