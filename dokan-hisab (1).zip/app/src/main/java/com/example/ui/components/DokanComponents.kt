package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Account
import com.example.data.model.DokanFormatter
import com.example.data.model.Transaction
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CrimsonDue
import com.example.ui.theme.EmeraldGreenPrimary

@Composable
fun DokanTopBar(
  shopName: String,
  onProfileClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    modifier = modifier.fillMaxWidth(),
    color = MaterialTheme.colorScheme.primary,
    shadowElevation = 4.dp
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        Box(
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(AmberAccent),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "৳",
            color = Color.Black,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = "Dokan Hisab",
            color = Color.White,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = shopName.ifBlank { "আমার মুদি দোকান" },
            color = Color.White.copy(alpha = 0.85f),
            style = MaterialTheme.typography.bodySmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
      }

      IconButton(
        onClick = onProfileClick,
        modifier = Modifier.testTag("top_settings_button")
      ) {
        Icon(
          imageVector = Icons.Default.Storefront,
          contentDescription = "দোকানের প্রোফাইল",
          tint = Color.White
        )
      }
    }
  }
}

@Composable
fun StatCard(
  title: String,
  value: String,
  icon: ImageVector,
  accentColor: Color,
  subtitle: String? = null,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(accentColor.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = icon,
          contentDescription = title,
          tint = accentColor,
          modifier = Modifier.size(24.dp)
        )
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = title,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = value,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        if (subtitle != null) {
          Text(
            text = subtitle,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
          )
        }
      }
    }
  }
}

@Composable
fun AccountBalancePill(
  account: Account,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val (color, icon) = when (account.type) {
    "cash" -> Pair(EmeraldGreenPrimary, Icons.Default.AccountBalanceWallet)
    "mobile_banking" -> Pair(Color(0xFFE2136E), Icons.Default.Payment)
    else -> Pair(Color(0xFF1565C0), Icons.Default.AccountBalance)
  }

  Surface(
    modifier = modifier
      .clip(RoundedCornerShape(12.dp))
      .clickable(onClick = onClick),
    shape = RoundedCornerShape(12.dp),
    color = color.copy(alpha = 0.1f)
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = icon,
        contentDescription = account.name,
        tint = color,
        modifier = Modifier.size(18.dp)
      )
      Spacer(modifier = Modifier.width(8.dp))
      Column {
        Text(
          text = account.name,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
          text = DokanFormatter.formatMoney(account.balance),
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.Bold,
          color = color
        )
      }
    }
  }
}

@Composable
fun TransactionRow(
  tx: Transaction,
  modifier: Modifier = Modifier
) {
  val isPositive = tx.type in listOf("sale", "collection")
  val isDebt = tx.type == "credit_sale"
  val isExpense = tx.type in listOf("expense", "supplier_payment")

  val (icon, tint, amountPrefix) = when (tx.type) {
    "sale" -> Triple(Icons.Default.AddShoppingCart, EmeraldGreenPrimary, "+")
    "credit_sale" -> Triple(Icons.Default.ReceiptLong, CrimsonDue, "+")
    "collection" -> Triple(Icons.Default.Payment, EmeraldGreenPrimary, "+")
    "purchase" -> Triple(Icons.Default.LocalShipping, AmberAccent, "+")
    "supplier_payment" -> Triple(Icons.Default.Payment, CrimsonDue, "-")
    "expense" -> Triple(Icons.Default.MoneyOff, CrimsonDue, "-")
    "transfer" -> Triple(Icons.Default.CompareArrows, Color(0xFF1565C0), "↔")
    else -> Triple(Icons.Default.AccountBalanceWallet, AmberAccent, "")
  }

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .clip(CircleShape)
          .background(tint.copy(alpha = 0.12f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = icon,
          contentDescription = tx.type,
          tint = tint,
          modifier = Modifier.size(20.dp)
        )
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = tx.note.ifBlank { DokanFormatter.typeLabel(tx.type) },
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Text(
            text = tx.date,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = "•",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Surface(
            shape = RoundedCornerShape(4.dp),
            color = MaterialTheme.colorScheme.surfaceVariant
          ) {
            Text(
              text = DokanFormatter.methodLabel(tx.method),
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
          Surface(
            shape = RoundedCornerShape(4.dp),
            color = tint.copy(alpha = 0.1f)
          ) {
            Text(
              text = DokanFormatter.typeLabel(tx.type),
              style = MaterialTheme.typography.labelSmall,
              color = tint,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }
      }
      Spacer(modifier = Modifier.width(8.dp))
      Column(horizontalAlignment = Alignment.End) {
        Text(
          text = "$amountPrefix${DokanFormatter.formatMoney(tx.amount)}",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = if (isExpense || isDebt) CrimsonDue else EmeraldGreenPrimary
        )
        if (tx.dueAmount > 0) {
          Text(
            text = "বাকি: ${DokanFormatter.formatMoney(tx.dueAmount)}",
            style = MaterialTheme.typography.labelSmall,
            color = CrimsonDue,
            fontWeight = FontWeight.Bold
          )
        } else if (tx.profit != null && tx.profit > 0) {
          Text(
            text = "লাভ: ${DokanFormatter.formatMoney(tx.profit)}",
            style = MaterialTheme.typography.labelSmall,
            color = EmeraldGreenPrimary
          )
        }
      }
    }
  }
}
