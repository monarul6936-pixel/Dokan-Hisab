package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Account
import com.example.data.model.DokanFormatter
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CrimsonDue
import com.example.ui.theme.EmeraldGreenPrimary
import com.example.ui.viewmodel.DokanViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountsScreen(
  viewModel: DokanViewModel,
  modifier: Modifier = Modifier
) {
  val accounts by viewModel.accounts.collectAsState()
  val transactions by viewModel.transactions.collectAsState()
  val financialReport by viewModel.financialReport.collectAsState()

  var showTransferDialog by remember { mutableStateOf(false) }
  var accountToEdit by remember { mutableStateOf<Account?>(null) }

  val totalLiquidFunds = accounts.sumOf { it.balance }
  val transferTxs = transactions.filter { it.type == "transfer" }.take(10)

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header
    item {
      Column {
        Text(
          text = "ক্যাশ বাক্স ও ব্যাংকিং",
          style = MaterialTheme.typography.headlineSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = "নগদ টাকা, বিকাশ, নগদ ও ব্যাংকের মোট ব্যালেন্স ও স্থানান্তর",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    // Total Liquid Balance Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "দোকানের মোট তরল তহবিল (ক্যাশ + ব্যাংক)",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer
              )
              Text(
                text = DokanFormatter.formatMoney(totalLiquidFunds),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
              )
            }

            Box(
              modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.AccountBalanceWallet,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(28.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          Button(
            onClick = { showTransferDialog = true },
            modifier = Modifier
              .fillMaxWidth()
              .height(44.dp)
              .testTag("open_transfer_dialog_btn"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreenPrimary)
          ) {
            Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("টাকা স্থানান্তর (ক্যাশ/বিকাশ/ব্যাংক)", fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // Account Cards Grid
    item {
      Text(
        text = "ব্যক্তিগত ও ব্যবসায়িক একাউন্টসমূহ",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
    }

    items(accounts, key = { it.id }) { acc ->
      val (icon: ImageVector, iconBg: Color) = when (acc.type) {
        "cash" -> Icons.Default.Money to EmeraldGreenPrimary
        "bkash" -> Icons.Default.PhoneAndroid to Color(0xFFD82260)
        "nagad" -> Icons.Default.PhoneAndroid to Color(0xFFE65100)
        "bank" -> Icons.Default.AccountBalance to Color(0xFF1565C0)
        else -> Icons.Default.AccountBalanceWallet to AmberAccent
      }

      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(iconBg.copy(alpha = 0.15f)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconBg,
                modifier = Modifier.size(24.dp)
              )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column {
              Text(
                text = acc.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "হালনাগাদ ব্যালেন্স",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = DokanFormatter.formatMoney(acc.balance),
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Bold,
              color = if (acc.balance >= 0) EmeraldGreenPrimary else CrimsonDue
            )

            Spacer(modifier = Modifier.width(6.dp))

            IconButton(
              onClick = { accountToEdit = acc },
              modifier = Modifier.size(32.dp)
            ) {
              Icon(
                Icons.Default.Edit,
                contentDescription = "ব্যালেন্স সমন্বয়",
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.size(16.dp)
              )
            }
          }
        }
      }
    }

    // Recent Transfers Section
    if (transferTxs.isNotEmpty()) {
      item {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "সাম্প্রতিক ফান্ড স্থানান্তর",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
      }

      items(transferTxs, key = { it.id }) { tx ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.SwapHoriz, contentDescription = null, tint = EmeraldGreenPrimary)
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(
                  text = tx.note.ifBlank { "ফান্ড স্থানান্তর" },
                  fontWeight = FontWeight.SemiBold,
                  style = MaterialTheme.typography.bodyMedium
                )
                Text(
                  text = tx.date,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            Text(
              text = DokanFormatter.formatMoney(tx.amount),
              fontWeight = FontWeight.Bold,
              style = MaterialTheme.typography.titleMedium,
              color = EmeraldGreenPrimary
            )
          }
        }
      }
    }
  }

  // Transfer Money Dialog
  if (showTransferDialog) {
    var fromAccId by remember { mutableStateOf(accounts.firstOrNull()?.id ?: "cash") }
    var toAccId by remember { mutableStateOf(accounts.getOrNull(1)?.id ?: "bkash") }
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    AlertDialog(
      onDismissRequest = { showTransferDialog = false },
      title = { Text("টাকা স্থানান্তর (এক একাউন্ট থেকে অন্যটিতে)") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          // From Account
          Text("যে একাউন্ট থেকে কাটবে (From):", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            accounts.forEach { acc ->
              val isSelected = fromAccId == acc.id
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isSelected) CrimsonDue else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                  .weight(1f)
                  .clickable { fromAccId = acc.id }
              ) {
                Text(
                  text = acc.name.replace(" একাউন্ট", "").replace(" ব্যালেন্স", ""),
                  modifier = Modifier.padding(vertical = 8.dp),
                  style = MaterialTheme.typography.bodySmall,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                  color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                  fontSize = 11.sp
                )
              }
            }
          }

          // To Account
          Text("যে একাউন্টে জমা হবে (To):", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            accounts.forEach { acc ->
              val isSelected = toAccId == acc.id
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isSelected) EmeraldGreenPrimary else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                  .weight(1f)
                  .clickable { toAccId = acc.id }
              ) {
                Text(
                  text = acc.name.replace(" একাউন্ট", "").replace(" ব্যালেন্স", ""),
                  modifier = Modifier.padding(vertical = 8.dp),
                  style = MaterialTheme.typography.bodySmall,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                  color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                  fontSize = 11.sp
                )
              }
            }
          }

          OutlinedTextField(
            value = amountText,
            onValueChange = { amountText = it },
            label = { Text("স্থানান্তরের পরিমাণ (৳) *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("transfer_amount_input")
          )

          OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            label = { Text("নোট / কারণ") },
            placeholder = { Text("যেমন: ব্যাংক থেকে ক্যাশ উত্তোলন") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val amount = amountText.toDoubleOrNull() ?: 0.0
            if (amount > 0 && fromAccId != toAccId) {
              viewModel.recordTransfer(
                fromAccountId = fromAccId,
                toAccountId = toAccId,
                amount = amount,
                note = note
              ) {
                showTransferDialog = false
              }
            }
          },
          enabled = (amountText.toDoubleOrNull() ?: 0.0) > 0 && fromAccId != toAccId,
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreenPrimary),
          modifier = Modifier.testTag("confirm_transfer_btn")
        ) {
          Text("স্থানান্তর নিশ্চিত করুন")
        }
      },
      dismissButton = {
        TextButton(onClick = { showTransferDialog = false }) {
          Text("বাতিল")
        }
      }
    )
  }

  // Edit Account Balance Dialog
  if (accountToEdit != null) {
    val acc = accountToEdit!!
    var balText by remember { mutableStateOf(acc.balance.toString().replace(".0", "")) }

    AlertDialog(
      onDismissRequest = { accountToEdit = null },
      title = { Text("${acc.name} - ব্যালেন্স সমন্বয়") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("হিসাব মেলানোর জন্য সঠিক ব্যালেন্স লিখুন:", style = MaterialTheme.typography.bodyMedium)
          OutlinedTextField(
            value = balText,
            onValueChange = { balText = it },
            label = { Text("সঠিক ব্যালেন্স (৳)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val newBal = balText.toDoubleOrNull() ?: 0.0
            viewModel.updateAccountBalance(acc.id, newBal)
            accountToEdit = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreenPrimary)
        ) {
          Text("হালনাগাদ করুন")
        }
      },
      dismissButton = {
        TextButton(onClick = { accountToEdit = null }) {
          Text("বাতিল")
        }
      }
    )
  }
}
