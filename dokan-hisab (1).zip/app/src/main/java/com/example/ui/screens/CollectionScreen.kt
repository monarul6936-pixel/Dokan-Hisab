package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.DokanFormatter
import com.example.ui.components.TransactionRow
import com.example.ui.theme.CrimsonDue
import com.example.ui.theme.EmeraldGreenPrimary
import com.example.ui.viewmodel.DokanViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CollectionScreen(
  viewModel: DokanViewModel,
  preselectedCustomer: Customer? = null,
  modifier: Modifier = Modifier
) {
  val customers by viewModel.customers.collectAsState()
  val customerDues by viewModel.customerDues.collectAsState()
  val transactions by viewModel.transactions.collectAsState()

  var selectedCustomer by remember(preselectedCustomer) { mutableStateOf(preselectedCustomer) }
  var customerExpanded by remember { mutableStateOf(false) }

  var amountText by remember { mutableStateOf("") }
  var selectedMethod by remember { mutableStateOf("cash") }

  val due = selectedCustomer?.let { customerDues[it.id] ?: it.opening } ?: 0.0
  val amount = amountText.toDoubleOrNull() ?: 0.0

  val recentCollections = transactions.filter { it.type == "collection" }.take(10)

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Column {
        Text(
          text = "বাকি আদায় (Collection)",
          style = MaterialTheme.typography.headlineSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = "কাস্টমারের কাছ থেকে বাকি টাকা আদায় ও জমা সংরক্ষণ করুন",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    // Collection Form Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "কাস্টমার নির্বাচন করুন",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(10.dp))

          ExposedDropdownMenuBox(
            expanded = customerExpanded,
            onExpandedChange = { customerExpanded = !customerExpanded }
          ) {
            OutlinedTextField(
              value = selectedCustomer?.let { "${it.name} (বাকি: ${DokanFormatter.formatMoney(due)})" } ?: "",
              onValueChange = {},
              readOnly = true,
              label = { Text("কাস্টমার") },
              placeholder = { Text("তালিকা থেকে কাস্টমার বেছে নিন") },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = customerExpanded) },
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
                .testTag("collection_customer_dropdown")
            )

            ExposedDropdownMenu(
              expanded = customerExpanded,
              onDismissRequest = { customerExpanded = false }
            ) {
              val dueCustomers = customers.filter { (customerDues[it.id] ?: it.opening) > 0 }
              val otherCustomers = customers.filter { (customerDues[it.id] ?: it.opening) <= 0 }

              if (customers.isEmpty()) {
                DropdownMenuItem(
                  text = { Text("কোনো কাস্টমার পাওয়া যায়নি") },
                  onClick = { customerExpanded = false }
                )
              } else {
                (dueCustomers + otherCustomers).forEach { customer ->
                  val custDue = customerDues[customer.id] ?: customer.opening
                  DropdownMenuItem(
                    text = {
                      Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                      ) {
                        Text(text = customer.name, fontWeight = FontWeight.SemiBold)
                        Text(
                          text = "বাকি: ${DokanFormatter.formatMoney(custDue)}",
                          color = if (custDue > 0) CrimsonDue else EmeraldGreenPrimary,
                          fontWeight = FontWeight.Bold
                        )
                      }
                    },
                    onClick = {
                      selectedCustomer = customer
                      customerExpanded = false
                      // Pre-fill full due or leave empty
                    }
                  )
                }
              }
            }
          }

          if (selectedCustomer != null) {
            Spacer(modifier = Modifier.height(12.dp))
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .border(1.dp, CrimsonDue.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                .padding(12.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "বর্তমান মোট বাকি পাওনা",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                  text = DokanFormatter.formatMoney(due),
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = CrimsonDue
                )
              }
              if (due > 0) {
                Surface(
                  modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .clickable { amountText = String.format("%.2f", due).replace(".00", "") },
                  color = EmeraldGreenPrimary.copy(alpha = 0.12f)
                ) {
                  Text(
                    text = "পুরো টাকা বসান",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldGreenPrimary,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Amount
          OutlinedTextField(
            value = amountText,
            onValueChange = { amountText = it },
            label = { Text("আদায়ের পরিমাণ (৳) *") },
            placeholder = { Text("টাকার পরিমাণ লিখুন") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("collection_amount_input")
          )

          if (selectedCustomer != null && amount > due && due > 0) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "সতর্কতা: বাকি পাওনার (${DokanFormatter.formatMoney(due)}) চেয়ে বেশি টাকা আদায় করা যাবে না!",
              color = CrimsonDue,
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.Bold
            )
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Payment Method
          Text(
            text = "টাকা গ্রহণের মাধ্যম",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold
          )
          Spacer(modifier = Modifier.height(8.dp))

          val methods = listOf(
            Triple("cash", "নগদ", EmeraldGreenPrimary),
            Triple("bkash", "বিকাশ", Color(0xFFE2136E)),
            Triple("nagad", "নগদ অ্যাপ", Color(0xFFF7941D)),
            Triple("bank", "ব্যাংক", Color(0xFF1565C0))
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            methods.forEach { (key, label, color) ->
              val isSelected = selectedMethod == key
              Card(
                modifier = Modifier
                  .weight(1f)
                  .clip(RoundedCornerShape(10.dp))
                  .clickable { selectedMethod = key }
                  .border(
                    width = if (isSelected) 2.dp else 1.dp,
                    color = if (isSelected) color else MaterialTheme.colorScheme.outlineVariant,
                    shape = RoundedCornerShape(10.dp)
                  ),
                colors = CardDefaults.cardColors(
                  containerColor = if (isSelected) color.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
                )
              ) {
                Column(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                  horizontalAlignment = Alignment.CenterHorizontally
                ) {
                  Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSelected) color else MaterialTheme.colorScheme.onSurface
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(20.dp))

          Button(
            onClick = {
              val c = selectedCustomer ?: return@Button
              viewModel.addCollection(
                customerId = c.id,
                amount = amount,
                method = selectedMethod,
                onSuccess = {
                  amountText = ""
                  selectedCustomer = null
                }
              )
            },
            enabled = selectedCustomer != null && amount > 0 && (due <= 0 || amount <= due),
            modifier = Modifier
              .fillMaxWidth()
              .height(50.dp)
              .testTag("submit_collection_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreenPrimary)
          ) {
            Icon(Icons.Default.CheckCircle, contentDescription = "আদায় নিশ্চিত করুন")
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "বাকি আদায় সংরক্ষণ করুন",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }

    // Recent Collections Header
    item {
      Text(
        text = "সাম্প্রতিক বাকি আদায়ের হিসাব",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
    }

    if (recentCollections.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Text(
            text = "এখনো কোনো বাকি আদায় রেকর্ড করা হয়নি।",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(24.dp)
          )
        }
      }
    } else {
      items(recentCollections, key = { it.id }) { tx ->
        TransactionRow(tx = tx)
      }
    }
  }
}
