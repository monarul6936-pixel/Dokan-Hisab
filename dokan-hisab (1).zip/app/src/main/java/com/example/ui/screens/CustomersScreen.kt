package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.DokanFormatter
import com.example.ui.components.TransactionRow
import com.example.ui.theme.CrimsonDue
import com.example.ui.theme.EmeraldGreenPrimary
import com.example.ui.viewmodel.DokanViewModel

@Composable
fun CustomersScreen(
  viewModel: DokanViewModel,
  onNavigateToCollectionForCustomer: (Customer) -> Unit,
  modifier: Modifier = Modifier
) {
  val customers by viewModel.customers.collectAsState()
  val customerDues by viewModel.customerDues.collectAsState()
  val transactions by viewModel.transactions.collectAsState()
  val searchQuery by viewModel.customerSearch.collectAsState()
  val context = LocalContext.current

  var showAddDialog by remember { mutableStateOf(false) }
  var customerToEdit by remember { mutableStateOf<Customer?>(null) }
  var customerToDelete by remember { mutableStateOf<Customer?>(null) }
  var customerLedgerView by remember { mutableStateOf<Customer?>(null) }

  val totalDueAll = customerDues.values.filter { it > 0 }.sum()

  val filteredCustomers = remember(customers, searchQuery) {
    if (searchQuery.isBlank()) customers
    else customers.filter {
      it.name.contains(searchQuery, ignoreCase = true) || it.phone.contains(searchQuery)
    }
  }

  Box(modifier = modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp),
      contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // Header & Total Due Banner
      item {
        Column {
          Text(
            text = "কাস্টমার ও বাকির খাতা",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = "বাকি খাতার হিসাব, পাওনা টাকা ও আদায়ের খতিয়ান",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(12.dp))

          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CrimsonDue.copy(alpha = 0.12f))
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "মোট বাকি পাওনা",
                  style = MaterialTheme.typography.bodySmall,
                  color = CrimsonDue
                )
                Text(
                  text = DokanFormatter.formatMoney(totalDueAll),
                  style = MaterialTheme.typography.headlineMedium,
                  fontWeight = FontWeight.Bold,
                  color = CrimsonDue
                )
              }
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = CrimsonDue.copy(alpha = 0.2f)
              ) {
                Text(
                  text = "${customers.size} জন কাস্টমার",
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold,
                  color = CrimsonDue,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
              }
            }
          }
        }
      }

      // Search Bar
      item {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { viewModel.setCustomerSearch(it) },
          label = { Text("কাস্টমারের নাম বা মোবাইল খুঁজুন...") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = "অনুসন্ধান") },
          trailingIcon = {
            if (searchQuery.isNotEmpty()) {
              IconButton(onClick = { viewModel.setCustomerSearch("") }) {
                Icon(Icons.Default.Clear, contentDescription = "মুছুন")
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("search_customer_input")
        )
      }

      // Customer List
      if (filteredCustomers.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
          ) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = if (searchQuery.isNotEmpty()) "কোনো কাস্টমার মেলেনি" else "এখনো কোনো কাস্টমার যোগ করা হয়নি। নতুন কাস্টমার যোগ করুন।",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      } else {
        items(filteredCustomers, key = { it.id }) { customer ->
          val due = customerDues[customer.id] ?: customer.opening
          CustomerCard(
            customer = customer,
            due = due,
            onCardClick = { customerLedgerView = customer },
            onCollectClick = { onNavigateToCollectionForCustomer(customer) },
            onEdit = { customerToEdit = customer },
            onDelete = { customerToDelete = customer },
            onCallClick = {
              if (customer.phone.isNotBlank()) {
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${customer.phone}"))
                context.startActivity(intent)
              }
            }
          )
        }
      }
    }

    // Add Customer FAB
    FloatingActionButton(
      onClick = { showAddDialog = true },
      containerColor = MaterialTheme.colorScheme.primary,
      contentColor = Color.White,
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(bottom = 76.dp, end = 20.dp)
        .testTag("add_customer_fab")
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(Icons.Default.Add, contentDescription = "কাস্টমার যোগ করুন")
        Spacer(modifier = Modifier.width(6.dp))
        Text("নতুন কাস্টমার", fontWeight = FontWeight.Bold)
      }
    }
  }

  // Add / Edit Customer Dialog
  if (showAddDialog || customerToEdit != null) {
    CustomerFormDialog(
      initialCustomer = customerToEdit,
      onDismiss = {
        showAddDialog = false
        customerToEdit = null
      },
      onSave = { name, phone, opening ->
        viewModel.saveCustomer(
          id = customerToEdit?.id,
          name = name,
          phone = phone,
          opening = opening,
          onSuccess = {
            showAddDialog = false
            customerToEdit = null
          }
        )
      }
    )
  }

  // Customer Ledger History Dialog (Khata Detail)
  if (customerLedgerView != null) {
    val cust = customerLedgerView!!
    val due = customerDues[cust.id] ?: cust.opening
    val customerTxs = transactions.filter { it.customerId == cust.id }

    AlertDialog(
      onDismissRequest = { customerLedgerView = null },
      title = {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(text = cust.name, fontWeight = FontWeight.Bold)
            if (cust.phone.isNotBlank()) {
              Text(
                text = cust.phone,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (due > 0) CrimsonDue.copy(alpha = 0.15f) else EmeraldGreenPrimary.copy(alpha = 0.15f)
          ) {
            Text(
              text = "বাকি: ${DokanFormatter.formatMoney(due)}",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = if (due > 0) CrimsonDue else EmeraldGreenPrimary,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }
      },
      text = {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .height(350.dp)
        ) {
          if (cust.opening > 0) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = "পূর্বের জের (Opening Balance):",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Text(
                text = DokanFormatter.formatMoney(cust.opening),
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = CrimsonDue
              )
            }
          }

          Text(
            text = "লেনদেনের খতিয়ান (${customerTxs.size} টি)",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(vertical = 4.dp)
          )

          if (customerTxs.isEmpty()) {
            Box(
              modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "এই কাস্টমারের কোনো নতুন লেনদেন নেই।",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          } else {
            LazyColumn(
              modifier = Modifier.fillMaxSize(),
              verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              items(customerTxs, key = { it.id }) { tx ->
                TransactionRow(tx = tx)
              }
            }
          }
        }
      },
      confirmButton = {
        if (due > 0) {
          Button(
            onClick = {
              val c = customerLedgerView!!
              customerLedgerView = null
              onNavigateToCollectionForCustomer(c)
            },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreenPrimary)
          ) {
            Text("বাকি আদায় করুন")
          }
        }
      },
      dismissButton = {
        TextButton(onClick = { customerLedgerView = null }) {
          Text("বন্ধ করুন")
        }
      }
    )
  }

  // Delete Customer Confirmation
  if (customerToDelete != null) {
    AlertDialog(
      onDismissRequest = { customerToDelete = null },
      title = { Text("কাস্টমার মুছে ফেলতে চান?") },
      text = { Text("আপনি কি নিশ্চিত যে '${customerToDelete!!.name}' কে খাতা থেকে মুছে ফেলবেন?") },
      confirmButton = {
        Button(
          onClick = {
            viewModel.deleteCustomer(customerToDelete!!.id)
            customerToDelete = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = CrimsonDue)
        ) {
          Text("মুছে ফেলুন")
        }
      },
      dismissButton = {
        TextButton(onClick = { customerToDelete = null }) {
          Text("বাতিল")
        }
      }
    )
  }
}

@Composable
private fun CustomerCard(
  customer: Customer,
  due: Double,
  onCardClick: () -> Unit,
  onCollectClick: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
  onCallClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .clickable(onClick = onCardClick),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f)
        ) {
          Box(
            modifier = Modifier
              .size(42.dp)
              .clip(CircleShape)
              .background(if (due > 0) CrimsonDue.copy(alpha = 0.15f) else EmeraldGreenPrimary.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Person,
              contentDescription = customer.name,
              tint = if (due > 0) CrimsonDue else EmeraldGreenPrimary
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = customer.name,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = if (customer.phone.isNotBlank()) customer.phone else "মোবাইল নম্বর নেই",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Column(horizontalAlignment = Alignment.End) {
          Text(
            text = "মোট বাকি",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = DokanFormatter.formatMoney(due),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = if (due > 0) CrimsonDue else EmeraldGreenPrimary
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          if (customer.phone.isNotBlank()) {
            IconButton(onClick = onCallClick, modifier = Modifier.size(36.dp)) {
              Icon(Icons.Default.Call, contentDescription = "ফোন করুন", tint = EmeraldGreenPrimary)
            }
          }
          IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
            Icon(Icons.Default.Edit, contentDescription = "সম্পাদনা", tint = MaterialTheme.colorScheme.primary)
          }
          IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
            Icon(Icons.Default.Delete, contentDescription = "মুছুন", tint = CrimsonDue)
          }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Surface(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .clickable(onClick = onCardClick),
            color = MaterialTheme.colorScheme.surfaceVariant
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.History, contentDescription = "খতিয়ান", modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("খতিয়ান", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
          }

          if (due > 0) {
            Surface(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable(onClick = onCollectClick),
              color = EmeraldGreenPrimary
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.Payment, contentDescription = "বাকি আদায়", tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("আদায়", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.White)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun CustomerFormDialog(
  initialCustomer: Customer?,
  onDismiss: () -> Unit,
  onSave: (name: String, phone: String, opening: Double) -> Unit
) {
  var name by remember { mutableStateOf(initialCustomer?.name ?: "") }
  var phone by remember { mutableStateOf(initialCustomer?.phone ?: "") }
  var openingText by remember { mutableStateOf(initialCustomer?.opening?.let { String.format("%.2f", it).replace(".00", "") } ?: "0") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = if (initialCustomer != null) "কাস্টমার সম্পাদনা" else "নতুন কাস্টমার যোগ করুন",
        fontWeight = FontWeight.Bold
      )
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("কাস্টমারের নাম *") },
          placeholder = { Text("যেমন: আব্দুর রহিম") },
          singleLine = true,
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("customer_name_input")
        )
        OutlinedTextField(
          value = phone,
          onValueChange = { phone = it },
          label = { Text("মোবাইল নম্বর") },
          placeholder = { Text("01XXXXXXXXX") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          singleLine = true,
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("customer_phone_input")
        )
        OutlinedTextField(
          value = openingText,
          onValueChange = { openingText = it },
          label = { Text("পূর্বের বাকি (৳)") },
          placeholder = { Text("০") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("customer_opening_input")
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val opening = openingText.toDoubleOrNull() ?: 0.0
          onSave(name, phone, opening)
        },
        enabled = name.isNotBlank(),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
        modifier = Modifier.testTag("save_customer_btn")
      ) {
        Text("সংরক্ষণ করুন")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("বাতিল")
      }
    }
  )
}
