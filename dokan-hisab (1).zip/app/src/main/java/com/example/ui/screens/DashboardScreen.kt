package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DokanFormatter
import com.example.ui.components.StatCard
import com.example.ui.components.TransactionRow
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CrimsonDue
import com.example.ui.theme.EmeraldGreenPrimary
import com.example.ui.viewmodel.DokanViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
  viewModel: DokanViewModel,
  onNavigateToSale: () -> Unit,
  onNavigateToCustomers: () -> Unit,
  onNavigateToSuppliers: () -> Unit,
  onNavigateToAccounts: () -> Unit,
  onNavigateToCollection: () -> Unit,
  onNavigateToExpense: () -> Unit,
  onNavigateToProducts: () -> Unit,
  modifier: Modifier = Modifier
) {
  val summary by viewModel.summary.collectAsState()
  val recentTxs by viewModel.recentTransactions.collectAsState()
  val products by viewModel.products.collectAsState()
  val lowStockProducts = products.filter { it.stock <= 5.0 }

  val todayFormatted = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("bn", "BD")).format(Date())

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header Greeting
    item {
      Column {
        Text(
          text = "দোকানের ড্যাশবোর্ড",
          style = MaterialTheme.typography.headlineSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = todayFormatted,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    // Quick Action Bar - Row 1
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        QuickActionButton(
          label = "নতুন বিক্রি",
          icon = Icons.Default.AddShoppingCart,
          containerColor = EmeraldGreenPrimary,
          contentColor = Color.White,
          onClick = onNavigateToSale,
          modifier = Modifier.weight(1f)
        )
        QuickActionButton(
          label = "বাকি খাতা",
          icon = Icons.Default.People,
          containerColor = CrimsonDue,
          contentColor = Color.White,
          onClick = onNavigateToCustomers,
          modifier = Modifier.weight(1f)
        )
        QuickActionButton(
          label = "মহাজন খাতা",
          icon = Icons.Default.Business,
          containerColor = AmberAccent,
          contentColor = Color.Black,
          onClick = onNavigateToSuppliers,
          modifier = Modifier.weight(1f)
        )
        QuickActionButton(
          label = "ক্যাশ/ব্যাংক",
          icon = Icons.Default.AccountBalanceWallet,
          containerColor = MaterialTheme.colorScheme.surfaceVariant,
          contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
          onClick = onNavigateToAccounts,
          modifier = Modifier.weight(1f)
        )
      }
    }

    // Quick Action Bar - Row 2
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        QuickActionButton(
          label = "বাকি আদায়",
          icon = Icons.Default.Payment,
          containerColor = EmeraldGreenPrimary.copy(alpha = 0.15f),
          contentColor = EmeraldGreenPrimary,
          onClick = onNavigateToCollection,
          modifier = Modifier.weight(1f)
        )
        QuickActionButton(
          label = "দোকানের খরচ",
          icon = Icons.Default.MoneyOff,
          containerColor = CrimsonDue.copy(alpha = 0.15f),
          contentColor = CrimsonDue,
          onClick = onNavigateToExpense,
          modifier = Modifier.weight(1f)
        )
        QuickActionButton(
          label = "পণ্য মজুদ",
          icon = Icons.Default.Inventory,
          containerColor = MaterialTheme.colorScheme.surfaceVariant,
          contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
          onClick = onNavigateToProducts,
          modifier = Modifier.weight(1f)
        )
      }
    }

    // Primary KPI Stat Cards
    item {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          StatCard(
            title = "আজকের বিক্রি",
            value = DokanFormatter.formatMoney(summary.todaySales),
            icon = Icons.Default.Receipt,
            accentColor = EmeraldGreenPrimary,
            modifier = Modifier.weight(1f)
          )
          StatCard(
            title = "মোট বিক্রি",
            value = DokanFormatter.formatMoney(summary.totalSales),
            icon = Icons.Default.AttachMoney,
            accentColor = EmeraldGreenPrimary,
            modifier = Modifier.weight(1f)
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          StatCard(
            title = "কাস্টমার মোট বাকি",
            value = DokanFormatter.formatMoney(summary.totalDue),
            icon = Icons.Default.People,
            accentColor = CrimsonDue,
            modifier = Modifier.weight(1f)
          )
          StatCard(
            title = "মহাজন প্রদেয় দেনা",
            value = DokanFormatter.formatMoney(summary.totalSupplierPayable),
            icon = Icons.Default.Business,
            accentColor = CrimsonDue,
            modifier = Modifier.weight(1f)
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          StatCard(
            title = "হাতে নগদ ও ব্যাংক",
            value = DokanFormatter.formatMoney(summary.totalLiquidFunds),
            icon = Icons.Default.AccountBalanceWallet,
            accentColor = EmeraldGreenPrimary,
            modifier = Modifier.weight(1f)
          )
          StatCard(
            title = "প্রকৃত নিট লাভ",
            value = DokanFormatter.formatMoney(summary.netProfit),
            icon = Icons.Default.TrendingUp,
            accentColor = if (summary.netProfit >= 0) EmeraldGreenPrimary else CrimsonDue,
            modifier = Modifier.weight(1f)
          )
        }
      }
    }

    // Low Stock Alert Section
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
          containerColor = if (lowStockProducts.isNotEmpty()) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
          else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "সতর্কতা",
                tint = if (lowStockProducts.isNotEmpty()) CrimsonDue else MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "কম স্টক এলার্ট (${lowStockProducts.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
            Text(
              text = "স্টক দেখুন",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.primary,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.clickable { onNavigateToProducts() }
            )
          }

          Spacer(modifier = Modifier.height(10.dp))
          if (lowStockProducts.isEmpty()) {
            Text(
              text = "কোনো পণ্যের স্টক কম নেই। পর্যাপ্ত পণ্য রয়েছে।",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              lowStockProducts.take(4).forEach { p ->
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = p.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f)
                  )
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = CrimsonDue.copy(alpha = 0.15f)
                  ) {
                    Text(
                      text = "${p.stock} ${p.unit}",
                      style = MaterialTheme.typography.labelSmall,
                      fontWeight = FontWeight.Bold,
                      color = CrimsonDue,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                  }
                }
              }
            }
          }
        }
      }
    }

    // Recent Transactions Section Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "সাম্প্রতিক লেনদেন",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = "${recentTxs.size} টি লেনদেন",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    // Recent Transactions List
    if (recentTxs.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "এখনো কোনো লেনদেন রেকর্ড করা হয়নি।",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    } else {
      items(recentTxs, key = { it.id }) { tx ->
        TransactionRow(tx = tx)
      }
    }
  }
}

@Composable
private fun QuickActionButton(
  label: String,
  icon: ImageVector,
  containerColor: Color,
  contentColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .clip(RoundedCornerShape(12.dp))
      .clickable(onClick = onClick)
      .testTag("quick_action_${label}"),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = containerColor),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 12.dp, horizontal = 4.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = contentColor,
        modifier = Modifier.size(24.dp)
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = label,
        color = contentColor,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        maxLines = 1
      )
    }
  }
}
