package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.DokanFormatter
import com.example.ui.components.TransactionRow
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CrimsonDue
import com.example.ui.theme.EmeraldGreenPrimary
import com.example.ui.viewmodel.DokanViewModel

@Composable
fun ExpenseScreen(
  viewModel: DokanViewModel,
  modifier: Modifier = Modifier
) {
  val transactions by viewModel.transactions.collectAsState()
  var selectedTab by remember { mutableIntStateOf(0) } // 0: Shop Expense, 1: Other Transactions

  val expenses = transactions.filter { it.type == "expense" }
  val otherTransactions = transactions.filter { it.type == "other" }

  val totalExpenseAmount = expenses.sumOf { it.amount }

  // Form states for Expense
  var expenseNote by remember { mutableStateOf("") }
  var expenseAmountText by remember { mutableStateOf("") }
  var expenseMethod by remember { mutableStateOf("cash") }

  // Form states for Other Transactions
  var otherDirection by remember { mutableStateOf("টাকা গ্রহণ") }
  var otherNote by remember { mutableStateOf("") }
  var otherAmountText by remember { mutableStateOf("") }
  var otherMethod by remember { mutableStateOf("cash") }

  val methods = listOf(
    Triple("cash", "নগদ", EmeraldGreenPrimary),
    Triple("bkash", "বিকাশ", Color(0xFFE2136E)),
    Triple("nagad", "নগদ অ্যাপ", Color(0xFFF7941D)),
    Triple("bank", "ব্যাংক", Color(0xFF1565C0))
  )

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Column {
        Text(
          text = "দোকানের খরচ ও লেনদেন",
          style = MaterialTheme.typography.headlineSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = "দোকানের দৈনন্দিন খরচ ও ক্যাশবুকের অন্যান্য লেনদেন হিসাব",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    // Tab Row
    item {
      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.clip(RoundedCornerShape(12.dp))
      ) {
        Tab(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          text = {
            Text(
              text = "দোকানের খরচ (${expenses.size})",
              fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal
            )
          }
        )
        Tab(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          text = {
            Text(
              text = "অন্যান্য লেনদেন (${otherTransactions.size})",
              fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal
            )
          }
        )
      }
    }

    if (selectedTab == 0) {
      // Expense Form Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "নতুন খরচ যোগ করুন",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "মোট: ${DokanFormatter.formatMoney(totalExpenseAmount)}",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = CrimsonDue
              )
            }
            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
              value = expenseNote,
              onValueChange = { expenseNote = it },
              label = { Text("খরচের বিবরণ *") },
              placeholder = { Text("যেমন: চা-নাস্তা, বিদ্যুৎ বিল, দোকান ভাড়া") },
              singleLine = true,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("expense_note_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
              value = expenseAmountText,
              onValueChange = { expenseAmountText = it },
              label = { Text("টাকার পরিমাণ (৳) *") },
              placeholder = { Text("যেমন: ১২০") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("expense_amount_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
              text = "কোন টাকা থেকে পরিশোধ?",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              methods.forEach { (key, label, color) ->
                val isSelected = expenseMethod == key
                Card(
                  modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { expenseMethod = key }
                    .border(
                      width = if (isSelected) 2.dp else 1.dp,
                      color = if (isSelected) color else MaterialTheme.colorScheme.outlineVariant,
                      shape = RoundedCornerShape(10.dp)
                    ),
                  colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) color.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
                  )
                ) {
                  Column(
                    modifier = Modifier
                      .fillMaxWidth()
                      .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                  ) {
                    Text(
                      text = label,
                      style = MaterialTheme.typography.labelSmall,
                      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                      color = if (isSelected) color else MaterialTheme.colorScheme.onSurface
                    )
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
              onClick = {
                val amt = expenseAmountText.toDoubleOrNull() ?: 0.0
                viewModel.addExpense(
                  note = expenseNote,
                  amount = amt,
                  method = expenseMethod,
                  onSuccess = {
                    expenseNote = ""
                    expenseAmountText = ""
                  }
                )
              },
              enabled = expenseNote.isNotBlank() && (expenseAmountText.toDoubleOrNull() ?: 0.0) > 0,
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("submit_expense_button"),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = CrimsonDue)
            ) {
              Icon(Icons.Default.Add, contentDescription = "খরচ যোগ করুন")
              Spacer(modifier = Modifier.width(6.dp))
              Text("খরচ সংরক্ষণ করুন", fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      // Expense History
      item {
        Text(
          text = "খরচের ইতিহাস",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
      }

      if (expenses.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
          ) {
            Text(
              text = "কোনো খরচের হিসাব রেকর্ড করা হয়নি।",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.padding(24.dp)
            )
          }
        }
      } else {
        items(expenses, key = { it.id }) { tx ->
          TransactionRow(tx = tx)
        }
      }
    } else {
      // Other Transactions Form Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "অন্যান্য লেনদেন যোগ করুন",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))

            // Direction
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              listOf("টাকা গ্রহণ", "টাকা প্রদান").forEach { dir ->
                val isSelected = otherDirection == dir
                Card(
                  modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { otherDirection = dir }
                    .border(
                      width = if (isSelected) 2.dp else 1.dp,
                      color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                      shape = RoundedCornerShape(10.dp)
                    ),
                  colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                  )
                ) {
                  Column(
                    modifier = Modifier
                      .fillMaxWidth()
                      .padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                  ) {
                    Text(
                      text = dir,
                      style = MaterialTheme.typography.bodyMedium,
                      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                      color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                    )
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
              value = otherNote,
              onValueChange = { otherNote = it },
              label = { Text("লেনদেনের বিবরণ *") },
              placeholder = { Text("যেমন: ধার গ্রহণ / ফেরত") },
              singleLine = true,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("other_note_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
              value = otherAmountText,
              onValueChange = { otherAmountText = it },
              label = { Text("পরিমাণ (৳) *") },
              placeholder = { Text("যেমন: ৫০০") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("other_amount_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
              text = "মাধ্যম",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              methods.forEach { (key, label, color) ->
                val isSelected = otherMethod == key
                Card(
                  modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { otherMethod = key }
                    .border(
                      width = if (isSelected) 2.dp else 1.dp,
                      color = if (isSelected) color else MaterialTheme.colorScheme.outlineVariant,
                      shape = RoundedCornerShape(10.dp)
                    ),
                  colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) color.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
                  )
                ) {
                  Column(
                    modifier = Modifier
                      .fillMaxWidth()
                      .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                  ) {
                    Text(
                      text = label,
                      style = MaterialTheme.typography.labelSmall,
                      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                      color = if (isSelected) color else MaterialTheme.colorScheme.onSurface
                    )
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
              onClick = {
                val amt = otherAmountText.toDoubleOrNull() ?: 0.0
                viewModel.addOtherTransaction(
                  direction = otherDirection,
                  note = otherNote,
                  amount = amt,
                  method = otherMethod,
                  onSuccess = {
                    otherNote = ""
                    otherAmountText = ""
                  }
                )
              },
              enabled = otherNote.isNotBlank() && (otherAmountText.toDoubleOrNull() ?: 0.0) > 0,
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("submit_other_tx_button"),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
              Icon(Icons.Default.CheckCircle, contentDescription = "লেনদেন সংরক্ষণ করুন")
              Spacer(modifier = Modifier.width(6.dp))
              Text("লেনদেন সংরক্ষণ করুন", fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      // Other Transactions History
      item {
        Text(
          text = "অন্যান্য লেনদেনের ইতিহাস",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
      }

      if (otherTransactions.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
          ) {
            Text(
              text = "কোনো লেনদেন রেকর্ড করা হয়নি।",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.padding(24.dp)
            )
          }
        }
      } else {
        items(otherTransactions, key = { it.id }) { tx ->
          TransactionRow(tx = tx)
        }
      }
    }
  }
}
