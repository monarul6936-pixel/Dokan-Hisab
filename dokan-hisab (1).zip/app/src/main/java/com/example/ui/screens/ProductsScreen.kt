package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DokanFormatter
import com.example.data.model.Product
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CrimsonDue
import com.example.ui.theme.EmeraldGreenPrimary
import com.example.ui.viewmodel.DokanViewModel

@Composable
fun ProductsScreen(
  viewModel: DokanViewModel,
  modifier: Modifier = Modifier
) {
  val products by viewModel.products.collectAsState()
  val searchQuery by viewModel.productSearch.collectAsState()

  var showAddDialog by remember { mutableStateOf(false) }
  var productToEdit by remember { mutableStateOf<Product?>(null) }
  var productToDelete by remember { mutableStateOf<Product?>(null) }

  val filteredProducts = remember(products, searchQuery) {
    if (searchQuery.isBlank()) products
    else products.filter { it.name.contains(searchQuery, ignoreCase = true) }
  }

  val totalStockValue = products.sumOf { it.buy * it.stock }

  Box(modifier = modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp),
      contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // Header & Valuation
      item {
        Column {
          Text(
            text = "পণ্য ও স্টক ইনভেন্টরি",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = "দোকানের সকল পণ্য, ক্রয়-বিক্রয় মূল্য ও স্টক নিয়ন্ত্রণ করুন",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(12.dp))

          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "মোট পণ্য সংখ্যা",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                )
                Text(
                  text = "${products.size} টি পণ্য",
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onPrimaryContainer
                )
              }
              Column(horizontalAlignment = Alignment.End) {
                Text(
                  text = "স্টকের মোট ক্রয়মূল্য",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                )
                Text(
                  text = DokanFormatter.formatMoney(totalStockValue),
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onPrimaryContainer
                )
              }
            }
          }
        }
      }

      // Search Bar
      item {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { viewModel.setProductSearch(it) },
          label = { Text("পণ্য খুঁজুন...") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = "অনুসন্ধান") },
          trailingIcon = {
            if (searchQuery.isNotEmpty()) {
              IconButton(onClick = { viewModel.setProductSearch("") }) {
                Icon(Icons.Default.Clear, contentDescription = "মুছুন")
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("search_product_input")
        )
      }

      // Product List
      if (filteredProducts.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
          ) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = if (searchQuery.isNotEmpty()) "কোনো পণ্য মেলেনি" else "এখনো কোনো পণ্য যোগ করা হয়নি। নিচের + বাটনে চাপুন।",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      } else {
        items(filteredProducts, key = { it.id }) { product ->
          ProductCard(
            product = product,
            onEdit = { productToEdit = product },
            onDelete = { productToDelete = product },
            onQuickRestock = { addQty -> viewModel.quickRestock(product.id, addQty) }
          )
        }
      }
    }

    // Add Product Floating Action Button
    FloatingActionButton(
      onClick = { showAddDialog = true },
      containerColor = MaterialTheme.colorScheme.primary,
      contentColor = Color.White,
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(bottom = 76.dp, end = 20.dp)
        .testTag("add_product_fab")
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(Icons.Default.Add, contentDescription = "পণ্য যোগ করুন")
        Spacer(modifier = Modifier.width(6.dp))
        Text("নতুন পণ্য", fontWeight = FontWeight.Bold)
      }
    }
  }

  // Add / Edit Product Dialog
  if (showAddDialog || productToEdit != null) {
    ProductFormDialog(
      initialProduct = productToEdit,
      onDismiss = {
        showAddDialog = false
        productToEdit = null
      },
      onSave = { name, buy, sell, stock, unit ->
        viewModel.saveProduct(
          id = productToEdit?.id,
          name = name,
          buy = buy,
          sell = sell,
          stock = stock,
          unit = unit,
          onSuccess = {
            showAddDialog = false
            productToEdit = null
          }
        )
      }
    )
  }

  // Delete Confirmation Dialog
  if (productToDelete != null) {
    AlertDialog(
      onDismissRequest = { productToDelete = null },
      title = { Text("পণ্য মুছে ফেলতে চান?") },
      text = { Text("আপনি কি নিশ্চিত যে '${productToDelete!!.name}' পণ্যটি তালিকা থেকে মুছে ফেলতে চান?") },
      confirmButton = {
        Button(
          onClick = {
            viewModel.deleteProduct(productToDelete!!.id)
            productToDelete = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = CrimsonDue)
        ) {
          Text("মুছে ফেলুন")
        }
      },
      dismissButton = {
        TextButton(onClick = { productToDelete = null }) {
          Text("বাতিল")
        }
      }
    )
  }
}

@Composable
private fun ProductCard(
  product: Product,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
  onQuickRestock: (Double) -> Unit,
  modifier: Modifier = Modifier
) {
  val isLowStock = product.stock <= 5.0
  val margin = if (product.buy > 0) ((product.sell - product.buy) / product.buy * 100).toInt() else 0

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = product.name,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Surface(
              shape = RoundedCornerShape(4.dp),
              color = EmeraldGreenPrimary.copy(alpha = 0.12f)
            ) {
              Text(
                text = "লাভ ~$margin%",
                style = MaterialTheme.typography.labelSmall,
                color = EmeraldGreenPrimary,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
            Text(
              text = "একক: ${product.unit}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Row {
          IconButton(onClick = onEdit) {
            Icon(Icons.Default.Edit, contentDescription = "সম্পাদনা", tint = MaterialTheme.colorScheme.primary)
          }
          IconButton(onClick = onDelete) {
            Icon(Icons.Default.Delete, contentDescription = "মুছুন", tint = CrimsonDue)
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(MaterialTheme.colorScheme.surfaceVariant)
          .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "ক্রয়মূল্য",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = DokanFormatter.formatMoney(product.buy),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold
          )
        }
        Column {
          Text(
            text = "বিক্রয়মূল্য",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = DokanFormatter.formatMoney(product.sell),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
        }
        Column(horizontalAlignment = Alignment.End) {
          Text(
            text = "বর্তমান স্টক",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Row(verticalAlignment = Alignment.CenterVertically) {
            if (isLowStock) {
              Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "কম স্টক",
                tint = CrimsonDue,
                modifier = Modifier.size(14.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
            }
            Text(
              text = "${product.stock} ${product.unit}",
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.Bold,
              color = if (isLowStock) CrimsonDue else EmeraldGreenPrimary
            )
          }
        }
      }

      // Quick restock buttons
      Spacer(modifier = Modifier.height(8.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "দ্রুত স্টক বৃদ্ধি:",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf(1.0, 5.0, 10.0).forEach { qty ->
            Surface(
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .clickable { onQuickRestock(qty) },
              color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
            ) {
              Text(
                text = "+${qty.toInt()}",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProductFormDialog(
  initialProduct: Product?,
  onDismiss: () -> Unit,
  onSave: (name: String, buy: Double, sell: Double, stock: Double, unit: String) -> Unit
) {
  var name by remember { mutableStateOf(initialProduct?.name ?: "") }
  var buyText by remember { mutableStateOf(initialProduct?.buy?.let { String.format("%.2f", it).replace(".00", "") } ?: "") }
  var sellText by remember { mutableStateOf(initialProduct?.sell?.let { String.format("%.2f", it).replace(".00", "") } ?: "") }
  var stockText by remember { mutableStateOf(initialProduct?.stock?.let { String.format("%.2f", it).replace(".00", "") } ?: "") }
  var unit by remember { mutableStateOf(initialProduct?.unit ?: "টি") }
  var unitExpanded by remember { mutableStateOf(false) }

  val unitOptions = listOf("টি", "কেজি", "গ্রাম", "লিটার", "প্যাকেট", "ডজন", "বস্তা", "বক্স")

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = if (initialProduct != null) "পণ্য সম্পাদনা করুন" else "নতুন পণ্য যোগ করুন",
        fontWeight = FontWeight.Bold
      )
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("পণ্যের নাম *") },
          placeholder = { Text("যেমন: মিনিকেট চাল") },
          singleLine = true,
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("product_name_input")
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = buyText,
            onValueChange = { buyText = it },
            label = { Text("ক্রয়মূল্য (৳) *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .weight(1f)
              .testTag("product_buy_input")
          )
          OutlinedTextField(
            value = sellText,
            onValueChange = { sellText = it },
            label = { Text("বিক্রয়মূল্য (৳) *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .weight(1f)
              .testTag("product_sell_input")
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = stockText,
            onValueChange = { stockText = it },
            label = { Text("মজুদ পরিমাণ *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .weight(1f)
              .testTag("product_stock_input")
          )

          ExposedDropdownMenuBox(
            expanded = unitExpanded,
            onExpandedChange = { unitExpanded = !unitExpanded },
            modifier = Modifier.weight(1f)
          ) {
            OutlinedTextField(
              value = unit,
              onValueChange = {},
              readOnly = true,
              label = { Text("একক") },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = unitExpanded) },
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.menuAnchor()
            )
            ExposedDropdownMenu(
              expanded = unitExpanded,
              onDismissRequest = { unitExpanded = false }
            ) {
              unitOptions.forEach { opt ->
                DropdownMenuItem(
                  text = { Text(opt) },
                  onClick = {
                    unit = opt
                    unitExpanded = false
                  }
                )
              }
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val buy = buyText.toDoubleOrNull() ?: 0.0
          val sell = sellText.toDoubleOrNull() ?: 0.0
          val stock = stockText.toDoubleOrNull() ?: 0.0
          onSave(name, buy, sell, stock, unit)
        },
        enabled = name.isNotBlank() && buyText.isNotBlank() && sellText.isNotBlank() && stockText.isNotBlank(),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
        modifier = Modifier.testTag("save_product_btn")
      ) {
        Text("সংরক্ষণ করুন")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("বাতিল")
      }
    }
  )
}
