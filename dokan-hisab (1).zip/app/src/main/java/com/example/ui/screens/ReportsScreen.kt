package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DokanFormatter
import com.example.ui.components.StatCard
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CrimsonDue
import com.example.ui.theme.EmeraldGreenPrimary
import com.example.ui.viewmodel.DateRangeFilter
import com.example.ui.viewmodel.DokanViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReportsScreen(
  viewModel: DokanViewModel,
  modifier: Modifier = Modifier
) {
  val financialReport by viewModel.financialReport.collectAsState()
  val shopInfo by viewModel.shopInfo.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()
  val activeFilter by viewModel.reportDateFilter.collectAsState()
  val context = LocalContext.current

  var showEditShopDialog by remember { mutableStateOf(false) }
  var showSignOutConfirmDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header
    item {
      Column {
        Text(
          text = "দোকানের হিসাব ও রিপোর্ট",
          style = MaterialTheme.typography.headlineSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = "আয়-ব্যয়, লাভ-ক্ষতি ও ব্যবসায়িক সম্পত্তির সামগ্রিক বিবরণ",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    // Filter Chips: Today, This Month, All Time
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        DateRangeFilter.values().forEach { filter ->
          val isSelected = activeFilter == filter
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (isSelected) EmeraldGreenPrimary else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
              .weight(1f)
              .clickable { viewModel.setReportDateFilter(filter) }
          ) {
            Box(
              modifier = Modifier.padding(vertical = 10.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = filter.label,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }
      }
    }

    // Section 1: Profit & Loss Statement (লাভ-ক্ষতি বিবরণী)
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.TrendingUp, contentDescription = null, tint = EmeraldGreenPrimary)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "${activeFilter.label} লাভ-ক্ষতির হিসাব (P&L)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )
            }

            IconButton(onClick = {
              val shareText = buildString {
                appendLine("📊 ${shopInfo?.name ?: "আমার মুদি দোকান"} - ${activeFilter.label} হিসাব")
                appendLine("তারিখ: ${SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())}")
                appendLine("------------------------------")
                appendLine("মোট বিক্রি: ${DokanFormatter.formatMoney(financialReport.totalSales)}")
                appendLine("বিক্রিত পণ্যের ক্রয়মূল্য: ${DokanFormatter.formatMoney(financialReport.costOfGoodsSold)}")
                appendLine("মোট লাভ (Gross): ${DokanFormatter.formatMoney(financialReport.grossProfit)}")
                appendLine("পরিচালন খরচ: ${DokanFormatter.formatMoney(financialReport.operatingExpenses)}")
                appendLine("প্রকৃত নিট লাভ (Net): ${DokanFormatter.formatMoney(financialReport.netProfit)}")
                appendLine("------------------------------")
                appendLine("কাস্টমার বাকি: ${DokanFormatter.formatMoney(financialReport.totalCustomerDue)}")
                appendLine("মহাজন দেনা: ${DokanFormatter.formatMoney(financialReport.totalSupplierPayable)}")
                appendLine("হাতে নগদ ও ব্যাংক: ${DokanFormatter.formatMoney(financialReport.totalLiquidFunds)}")
              }
              val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, shareText)
                type = "text/plain"
              }
              context.startActivity(Intent.createChooser(sendIntent, "হিসাবের বিবরণ শেয়ার করুন"))
            }) {
              Icon(Icons.Default.Share, contentDescription = "শেয়ার করুন", tint = EmeraldGreenPrimary)
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Line Items
          ReportRow(label = "১. মোট বিক্রয় (Gross Sales)", value = DokanFormatter.formatMoney(financialReport.totalSales))
          ReportRow(label = "২. বিক্রিত পণ্যের ক্রয়মূল্য (COGS)", value = "- " + DokanFormatter.formatMoney(financialReport.costOfGoodsSold), valueColor = CrimsonDue)
          HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
          ReportRow(label = "৩. মোট লাভ (Gross Profit)", value = DokanFormatter.formatMoney(financialReport.grossProfit), isBold = true, valueColor = EmeraldGreenPrimary)
          ReportRow(label = "৪. দোকানের পরিচালন খরচ (Expenses)", value = "- " + DokanFormatter.formatMoney(financialReport.operatingExpenses), valueColor = CrimsonDue)
          HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
          ReportRow(
            label = "৫. প্রকৃত নিট লাভ (Net Profit)",
            value = DokanFormatter.formatMoney(financialReport.netProfit),
            isBold = true,
            isLarge = true,
            valueColor = if (financialReport.netProfit >= 0) EmeraldGreenPrimary else CrimsonDue
          )
        }
      }
    }

    // Section 2: Asset & Valuation Breakdown (দোকানের সম্পত্তি ও দেনা-পাওনা)
    item {
      Text(
        text = "দোকানের মোট সম্পত্তি ও দেনা-পাওনা",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
    }

    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          AssetItem(
            icon = Icons.Default.Inventory,
            iconTint = EmeraldGreenPrimary,
            title = "মজুদ মালের ক্রয়মূল্য (Stock Valuation)",
            subtitle = "খুচরা বিক্রয়মূল্য: ${DokanFormatter.formatMoney(financialReport.totalStockRetailValue)}",
            amount = DokanFormatter.formatMoney(financialReport.totalStockCostValue)
          )

          HorizontalDivider()

          AssetItem(
            icon = Icons.Default.People,
            iconTint = AmberAccent,
            title = "বাজারে কাস্টমার বাকি (Receivables)",
            subtitle = "গ্রাহকদের কাছে পাওনা টাকা",
            amount = DokanFormatter.formatMoney(financialReport.totalCustomerDue)
          )

          HorizontalDivider()

          AssetItem(
            icon = Icons.Default.AccountBalanceWallet,
            iconTint = EmeraldGreenPrimary,
            title = "হাতে নগদ ক্যাশ ও ব্যাংকে জমা (Liquid Funds)",
            subtitle = "ক্যাশ বাক্স, বিকাশ, নগদ ও ব্যাংক ব্যালেন্স",
            amount = DokanFormatter.formatMoney(financialReport.totalLiquidFunds)
          )

          HorizontalDivider()

          AssetItem(
            icon = Icons.Default.Business,
            iconTint = CrimsonDue,
            title = "মহাজন / সাপ্লায়ারের দেনা (Payables)",
            subtitle = "পাইকারদের পরিশোধযোগ্য বকেয়া বিল",
            amount = DokanFormatter.formatMoney(financialReport.totalSupplierPayable),
            amountColor = CrimsonDue
          )
        }
      }
    }

    // Section 3: Shop Information & Firebase Cloud Sync
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Storefront, contentDescription = null, tint = EmeraldGreenPrimary)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "দোকানের প্রোফাইল ও ক্লাউড সিঙ্ক",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )
            }

            IconButton(onClick = { showEditShopDialog = true }) {
              Icon(Icons.Default.Edit, contentDescription = "সম্পাদনা", tint = EmeraldGreenPrimary)
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = shopInfo?.name?.ifBlank { "আমার মুদি দোকান" } ?: "আমার মুদি দোকান",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
          )

          if (!shopInfo?.phone.isNullOrBlank()) {
            Text(
              text = "মোবাইল: ${shopInfo?.phone}",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          if (!shopInfo?.address.isNullOrBlank()) {
            Text(
              text = "ঠিকানা: ${shopInfo?.address}",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .background(EmeraldGreenPrimary.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
              .padding(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.CloudDone, contentDescription = null, tint = EmeraldGreenPrimary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Firebase Firestore ক্লাউড ডাটাবেজে সুরক্ষিত ও সিঙ্কড",
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.SemiBold,
              color = EmeraldGreenPrimary
            )
          }

          if (currentUser != null) {
            Spacer(modifier = Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "লগইনকৃত একাউন্ট: ${currentUser?.email ?: currentUser?.displayName ?: "Google User"}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          OutlinedButton(
            onClick = { showSignOutConfirmDialog = true },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = CrimsonDue),
            shape = RoundedCornerShape(10.dp)
          ) {
            Icon(Icons.Default.ExitToApp, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("লগআউট করুন")
          }
        }
      }
    }
  }

  // Edit Shop Profile Dialog
  if (showEditShopDialog) {
    var name by remember { mutableStateOf(shopInfo?.name ?: "আমার মুদি দোকান") }
    var phone by remember { mutableStateOf(shopInfo?.phone ?: "") }
    var address by remember { mutableStateOf(shopInfo?.address ?: "") }

    AlertDialog(
      onDismissRequest = { showEditShopDialog = false },
      title = { Text("দোকানের তথ্য সম্পাদনা") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("দোকানের নাম *") },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("edit_shop_name_input")
          )
          OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("দোকানের মোবাইল নম্বর") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = address,
            onValueChange = { address = it },
            label = { Text("দোকানের ঠিকানা / বাজার") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (name.isNotBlank()) {
              viewModel.updateShopInfo(name.trim(), phone.trim(), address.trim())
              showEditShopDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreenPrimary)
        ) {
          Text("সংরক্ষণ করুন")
        }
      },
      dismissButton = {
        TextButton(onClick = { showEditShopDialog = false }) {
          Text("বাতিল")
        }
      }
    )
  }

  // Sign Out Dialog
  if (showSignOutConfirmDialog) {
    AlertDialog(
      onDismissRequest = { showSignOutConfirmDialog = false },
      title = { Text("লগআউট নিশ্চিতকরণ") },
      text = { Text("আপনি কি নিশ্চিতভাবে এই ডিভাইস থেকে লগআউট করতে চান? আপনার ডাটা ক্লাউডে নিরাপদে সংরক্ষিত থাকবে।") },
      confirmButton = {
        Button(
          onClick = {
            showSignOutConfirmDialog = false
            viewModel.signOut()
          },
          colors = ButtonDefaults.buttonColors(containerColor = CrimsonDue)
        ) {
          Text("লগআউট")
        }
      },
      dismissButton = {
        TextButton(onClick = { showSignOutConfirmDialog = false }) {
          Text("বাতিল")
        }
      }
    )
  }
}

@Composable
private fun ReportRow(
  label: String,
  value: String,
  isBold: Boolean = false,
  isLarge: Boolean = false,
  valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      text = label,
      style = if (isLarge) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium,
      fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal
    )
    Text(
      text = value,
      style = if (isLarge) MaterialTheme.typography.titleLarge else MaterialTheme.typography.bodyMedium,
      fontWeight = if (isBold) FontWeight.Bold else FontWeight.SemiBold,
      color = valueColor
    )
  }
}

@Composable
private fun AssetItem(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  iconTint: Color,
  title: String,
  subtitle: String,
  amount: String,
  amountColor: Color = EmeraldGreenPrimary
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
      Box(
        modifier = Modifier
          .size(38.dp)
          .clip(CircleShape)
          .background(iconTint.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
      }
      Spacer(modifier = Modifier.width(10.dp))
      Column {
        Text(text = title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
        Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    }

    Text(
      text = amount,
      fontWeight = FontWeight.Bold,
      style = MaterialTheme.typography.titleMedium,
      color = amountColor
    )
  }
}
