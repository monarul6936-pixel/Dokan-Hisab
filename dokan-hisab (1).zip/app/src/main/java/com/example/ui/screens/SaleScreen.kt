package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.DokanFormatter
import com.example.data.model.Product
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CrimsonDue
import com.example.ui.theme.EmeraldGreenPrimary
import com.example.ui.viewmodel.DokanViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SaleScreen(
  viewModel: DokanViewModel,
  modifier: Modifier = Modifier
) {
  val products by viewModel.products.collectAsState()
  val customers by viewModel.customers.collectAsState()
  val customerDues by viewModel.customerDues.collectAsState()
  val accounts by viewModel.accounts.collectAsState()

  val cart by viewModel.cart.collectAsState()
  val cartTotal by viewModel.cartTotal.collectAsState()
  val cartProfit by viewModel.cartProfit.collectAsState()

  // Selected product to add
  var selectedProduct by remember { mutableStateOf<Product?>(null) }
  var productExpanded by remember { mutableStateOf(false) }
  var productSearchText by remember { mutableStateOf("") }
  var quantityText by remember { mutableStateOf("1") }

  // Payment details
  var selectedAccountId by remember { mutableStateOf("cash") }
  var paidAmountText by remember { mutableStateOf("") }
  var selectedCustomer by remember { mutableStateOf<Customer?>(null) }
  var customerExpanded by remember { mutableStateOf(false) }
  var customerSearchText by remember { mutableStateOf("") }
  var saleNote by remember { mutableStateOf("") }

  // Auto-sync paid amount default when cart total changes
  LaunchedEffect(cartTotal) {
    if (paidAmountText.isEmpty() || paidAmountText.toDoubleOrNull() == 0.0) {
      paidAmountText = if (cartTotal > 0) cartTotal.toString().replace(".0", "") else ""
    }
  }

  val qtyToAdd = quantityText.toDoubleOrNull() ?: 1.0
  val parsedPaidAmount = paidAmountText.toDoubleOrNull() ?: cartTotal
  val dueAmount = (cartTotal - parsedPaidAmount).coerceAtLeast(0.0)

  val filteredProducts = remember(products, productSearchText) {
    if (productSearchText.isBlank()) products
    else products.filter { it.name.contains(productSearchText.trim(), ignoreCase = true) }
  }

  val filteredCustomers = remember(customers, customerSearchText) {
    if (customerSearchText.isBlank()) customers
    else customers.filter {
      it.name.contains(customerSearchText.trim(), ignoreCase = true) ||
        it.phone.contains(customerSearchText.trim())
    }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header
    item {
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "মাল্টি-আইটেম বিক্রি (POS)",
              style = MaterialTheme.typography.headlineSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "কার্টে একাধিক পণ্য যোগ করে নগদ বা বাকিতে বিক্রি করুন",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          if (cart.isNotEmpty()) {
            TextButton(
              onClick = { viewModel.clearCart() },
              colors = ButtonDefaults.textButtonColors(contentColor = CrimsonDue)
            ) {
              Icon(Icons.Default.Delete, contentDescription = "কার্ট খালি করুন", modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("কার্ট মুছুন")
            }
          }
        }
      }
    }

    // Step 1: Add Products to Cart
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.AddShoppingCart,
              contentDescription = null,
              tint = EmeraldGreenPrimary,
              modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "১. কার্টে পণ্য যোগ করুন",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
          Spacer(modifier = Modifier.height(12.dp))

          // Product Selector Dropdown
          ExposedDropdownMenuBox(
            expanded = productExpanded,
            onExpandedChange = { productExpanded = !productExpanded }
          ) {
            OutlinedTextField(
              value = selectedProduct?.let { "${it.name} - ${DokanFormatter.formatMoney(it.sell)}/${it.unit}" } ?: "",
              onValueChange = {},
              readOnly = true,
              label = { Text("পণ্য নির্বাচন") },
              placeholder = { Text("তালিকা থেকে পণ্য বেছে নিন") },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = productExpanded) },
              modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
                .testTag("product_dropdown"),
              shape = RoundedCornerShape(12.dp)
            )

            ExposedDropdownMenu(
              expanded = productExpanded,
              onDismissRequest = { productExpanded = false }
            ) {
              // Search input inside dropdown
              OutlinedTextField(
                value = productSearchText,
                onValueChange = { productSearchText = it },
                placeholder = { Text("নাম দিয়ে খুঁজুন...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(8.dp),
                singleLine = true,
                shape = RoundedCornerShape(8.dp)
              )

              if (filteredProducts.isEmpty()) {
                DropdownMenuItem(
                  text = { Text("কোনো পণ্য খুঁজে পাওয়া যায়নি") },
                  onClick = { productExpanded = false }
                )
              } else {
                filteredProducts.forEach { product ->
                  DropdownMenuItem(
                    text = {
                      Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Column {
                          Text(text = product.name, fontWeight = FontWeight.Bold)
                          Text(
                            text = "বিক্রয়: ${DokanFormatter.formatMoney(product.sell)} / ${product.unit}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                          )
                        }
                        Text(
                          text = "স্টক: ${product.stock} ${product.unit}",
                          style = MaterialTheme.typography.bodySmall,
                          color = if (product.stock <= 5) CrimsonDue else EmeraldGreenPrimary,
                          fontWeight = FontWeight.SemiBold
                        )
                      }
                    },
                    onClick = {
                      selectedProduct = product
                      productExpanded = false
                      productSearchText = ""
                    }
                  )
                }
              }
            }
          }

          // If product selected, show quantity controls and Add button
          if (selectedProduct != null) {
            val prod = selectedProduct!!
            Spacer(modifier = Modifier.height(12.dp))

            Surface(
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
              shape = RoundedCornerShape(12.dp)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(text = prod.name, fontWeight = FontWeight.Bold)
                  Text(
                    text = "মজুদ: ${prod.stock} ${prod.unit} • লাভ: ${DokanFormatter.formatMoney(prod.sell - prod.buy)}/${prod.unit}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }

                Text(
                  text = DokanFormatter.formatMoney(qtyToAdd * prod.sell),
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = EmeraldGreenPrimary
                )
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              // Quantity stepper
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                  .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                  .padding(horizontal = 4.dp, vertical = 2.dp)
              ) {
                IconButton(
                  onClick = {
                    val current = quantityText.toDoubleOrNull() ?: 1.0
                    if (current > 1) quantityText = (current - 1).toString().replace(".0", "")
                  },
                  modifier = Modifier.size(36.dp)
                ) {
                  Icon(Icons.Default.Remove, contentDescription = "কমান", modifier = Modifier.size(18.dp))
                }

                OutlinedTextField(
                  value = quantityText,
                  onValueChange = { quantityText = it },
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                  singleLine = true,
                  modifier = Modifier
                    .width(70.dp)
                    .testTag("product_quantity_input"),
                  shape = RoundedCornerShape(8.dp)
                )

                IconButton(
                  onClick = {
                    val current = quantityText.toDoubleOrNull() ?: 1.0
                    quantityText = (current + 1).toString().replace(".0", "")
                  },
                  modifier = Modifier.size(36.dp)
                ) {
                  Icon(Icons.Default.Add, contentDescription = "বাড়ান", modifier = Modifier.size(18.dp))
                }
              }

              Button(
                onClick = {
                  if (qtyToAdd > 0) {
                    viewModel.addToCart(prod, qtyToAdd)
                    selectedProduct = null
                    quantityText = "1"
                  }
                },
                enabled = qtyToAdd > 0 && qtyToAdd <= prod.stock,
                modifier = Modifier
                  .weight(1f)
                  .height(48.dp)
                  .testTag("add_to_cart_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreenPrimary)
              ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("কার্টে যোগ করুন")
              }
            }
          }
        }
      }
    }

    // Step 2: Live Cart View
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = EmeraldGreenPrimary, modifier = Modifier.size(22.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "২. বিক্রয় কার্ট (${cart.size} টি পণ্য)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )
            }

            if (cart.isNotEmpty()) {
              Text(
                text = DokanFormatter.formatMoney(cartTotal),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = EmeraldGreenPrimary
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          if (cart.isEmpty()) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp),
              contentAlignment = Alignment.Center
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                  imageVector = Icons.Default.ShoppingBag,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                  modifier = Modifier.size(44.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                  text = "কার্ট খালি! ওপর থেকে পণ্য নির্বাচন করে যোগ করুন।",
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              cart.forEach { item ->
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(text = item.name, fontWeight = FontWeight.SemiBold)
                      Text(
                        text = "${item.qty} ${item.unit} × ${DokanFormatter.formatMoney(item.sellPrice)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                      IconButton(
                        onClick = { viewModel.updateCartItemQty(item.productId, item.qty - 1) },
                        modifier = Modifier.size(30.dp)
                      ) {
                        Icon(Icons.Default.Remove, contentDescription = "কমান", modifier = Modifier.size(16.dp))
                      }

                      Text(
                        text = "${item.qty}",
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp)
                      )

                      IconButton(
                        onClick = { viewModel.updateCartItemQty(item.productId, item.qty + 1) },
                        modifier = Modifier.size(30.dp)
                      ) {
                        Icon(Icons.Default.Add, contentDescription = "বাড়ান", modifier = Modifier.size(16.dp))
                      }

                      Spacer(modifier = Modifier.width(8.dp))

                      Text(
                        text = DokanFormatter.formatMoney(item.total),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                      )

                      IconButton(
                        onClick = { viewModel.removeFromCart(item.productId) },
                        modifier = Modifier.size(32.dp)
                      ) {
                        Icon(Icons.Default.Clear, contentDescription = "মুছুন", tint = CrimsonDue, modifier = Modifier.size(18.dp))
                      }
                    }
                  }
                }
              }

              HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = "সম্ভাব্য মোট লাভ:",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                  text = DokanFormatter.formatMoney(cartProfit),
                  style = MaterialTheme.typography.bodySmall,
                  fontWeight = FontWeight.Bold,
                  color = EmeraldGreenPrimary
                )
              }
            }
          }
        }
      }
    }

    // Step 3: Payment & Settlement
    if (cart.isNotEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "৩. পেমেন্ট ও গ্রাহক নিষ্পত্তি",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Payment Account Selection
            Text(
              text = "পেমেন্ট মাধ্যম / একাউন্ট:",
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              val availableAccounts = accounts.ifEmpty {
                listOf(
                  com.example.data.model.Account("cash", "", "নগদ ক্যাশ", 0.0, "cash"),
                  com.example.data.model.Account("bkash", "", "বিকাশ", 0.0, "bkash"),
                  com.example.data.model.Account("nagad", "", "নগদ অ্যাপ", 0.0, "nagad"),
                  com.example.data.model.Account("bank", "", "ব্যাংক", 0.0, "bank")
                )
              }

              availableAccounts.take(4).forEach { acc ->
                val isSelected = selectedAccountId == acc.id
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = if (isSelected) EmeraldGreenPrimary else MaterialTheme.colorScheme.surfaceVariant,
                  modifier = Modifier
                    .weight(1f)
                    .clickable { selectedAccountId = acc.id }
                ) {
                  Column(
                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                  ) {
                    Text(
                      text = acc.name.replace(" একাউন্ট", "").replace(" ব্যালেন্স", ""),
                      style = MaterialTheme.typography.bodySmall,
                      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                      color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                    )
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Paid amount input
            OutlinedTextField(
              value = paidAmountText,
              onValueChange = { paidAmountText = it },
              label = { Text("পরিশোধিত টাকা (নগদ গ্রহণ)") },
              placeholder = { Text(cartTotal.toString()) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("paid_amount_input"),
              shape = RoundedCornerShape(12.dp),
              trailingIcon = {
                TextButton(onClick = { paidAmountText = cartTotal.toString().replace(".0", "") }) {
                  Text("পূর্ণ টাকা")
                }
              }
            )

            // Due indicator
            if (dueAmount > 0) {
              Spacer(modifier = Modifier.height(8.dp))
              Surface(
                color = CrimsonDue.copy(alpha = 0.1f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(
                  modifier = Modifier.padding(10.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = "বাকি থাকবে:",
                    fontWeight = FontWeight.SemiBold,
                    color = CrimsonDue
                  )
                  Text(
                    text = DokanFormatter.formatMoney(dueAmount),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = CrimsonDue
                  )
                }
              }

              Spacer(modifier = Modifier.height(12.dp))

              // Customer Selection for Due
              Text(
                text = "বাকির জন্য কাস্টমার নির্বাচন করুন (বাধ্যতামূলক):",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = CrimsonDue
              )
              Spacer(modifier = Modifier.height(6.dp))

              ExposedDropdownMenuBox(
                expanded = customerExpanded,
                onExpandedChange = { customerExpanded = !customerExpanded }
              ) {
                OutlinedTextField(
                  value = selectedCustomer?.let { c ->
                    val existingDue = customerDues[c.id] ?: c.opening
                    "${c.name} (${c.phone}) - পূর্বের বাকি: ${DokanFormatter.formatMoney(existingDue)}"
                  } ?: "",
                  onValueChange = {},
                  readOnly = true,
                  label = { Text("কাস্টমার খাতা") },
                  placeholder = { Text("কাস্টমার নির্বাচন করুন") },
                  trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = customerExpanded) },
                  modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth()
                    .testTag("customer_dropdown"),
                  shape = RoundedCornerShape(12.dp)
                )

                ExposedDropdownMenu(
                  expanded = customerExpanded,
                  onDismissRequest = { customerExpanded = false }
                ) {
                  OutlinedTextField(
                    value = customerSearchText,
                    onValueChange = { customerSearchText = it },
                    placeholder = { Text("নাম বা ফোন নম্বর দিয়ে খুঁজুন...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier
                      .fillMaxWidth()
                      .padding(8.dp),
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp)
                  )

                  if (filteredCustomers.isEmpty()) {
                    DropdownMenuItem(
                      text = { Text("কোনো কাস্টমার পাওয়া যায়নি (খাতা মেনু থেকে যোগ করুন)") },
                      onClick = { customerExpanded = false }
                    )
                  } else {
                    filteredCustomers.forEach { customer ->
                      val existingDue = customerDues[customer.id] ?: customer.opening
                      DropdownMenuItem(
                        text = {
                          Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                          ) {
                            Column {
                              Text(text = customer.name, fontWeight = FontWeight.Bold)
                              if (customer.phone.isNotBlank()) {
                                Text(
                                  text = customer.phone,
                                  style = MaterialTheme.typography.bodySmall,
                                  color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                              }
                            }
                            Text(
                              text = "বাকি: ${DokanFormatter.formatMoney(existingDue)}",
                              color = CrimsonDue,
                              fontWeight = FontWeight.SemiBold
                            )
                          }
                        },
                        onClick = {
                          selectedCustomer = customer
                          customerExpanded = false
                          customerSearchText = ""
                        }
                      )
                    }
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Note
            OutlinedTextField(
              value = saleNote,
              onValueChange = { saleNote = it },
              label = { Text("মন্তব্য / নোট (ঐচ্ছিক)") },
              placeholder = { Text("যেমন: ভাউচার নং বা ডেলিভারি তথ্য") },
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp),
              singleLine = true
            )
          }
        }
      }

      // Step 4: Confirm Checkout Button
      item {
        val isValid = cart.isNotEmpty() && (dueAmount == 0.0 || selectedCustomer != null)

        Button(
          onClick = {
            viewModel.checkoutSale(
              method = if (parsedPaidAmount <= 0) "credit" else selectedAccountId,
              accountId = selectedAccountId,
              customerId = selectedCustomer?.id,
              customerName = selectedCustomer?.name,
              paidAmount = parsedPaidAmount,
              note = saleNote,
              onSuccess = {
                paidAmountText = ""
                saleNote = ""
                selectedCustomer = null
              }
            )
          },
          enabled = isValid,
          modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .testTag("submit_sale_button"),
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = if (dueAmount > 0) AmberAccent else EmeraldGreenPrimary
          )
        ) {
          Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (dueAmount > 0) "বাকি সহ বিক্রি নিশ্চিত করুন (${DokanFormatter.formatMoney(cartTotal)})"
            else "বিক্রি সম্পন্ন করুন (${DokanFormatter.formatMoney(cartTotal)})",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }
      }
    }
  }
}
