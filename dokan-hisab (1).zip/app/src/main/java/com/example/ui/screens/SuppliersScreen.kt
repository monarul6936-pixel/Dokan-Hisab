package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CartItem
import com.example.data.model.DokanFormatter
import com.example.data.model.Product
import com.example.data.model.Supplier
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CrimsonDue
import com.example.ui.theme.EmeraldGreenPrimary
import com.example.ui.viewmodel.DokanViewModel
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SuppliersScreen(
  viewModel: DokanViewModel,
  modifier: Modifier = Modifier
) {
  val suppliers by viewModel.suppliers.collectAsState()
  val supplierPayables by viewModel.supplierPayables.collectAsState()
  val products by viewModel.products.collectAsState()
  val accounts by viewModel.accounts.collectAsState()
  val supplierSearch by viewModel.supplierSearch.collectAsState()

  var showAddDialog by remember { mutableStateOf(false) }
  var supplierToPay by remember { mutableStateOf<Supplier?>(null) }
  var supplierToRestock by remember { mutableStateOf<Supplier?>(null) }

  val totalPayable = suppliers.sumOf { s ->
    (supplierPayables[s.id] ?: s.opening).coerceAtLeast(0.0)
  }

  val filteredSuppliers = remember(suppliers, supplierSearch) {
    if (supplierSearch.isBlank()) suppliers
    else suppliers.filter {
      it.name.contains(supplierSearch.trim(), ignoreCase = true) ||
        it.company.contains(supplierSearch.trim(), ignoreCase = true) ||
        it.phone.contains(supplierSearch.trim())
    }
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    floatingActionButton = {
      FloatingActionButton(
        onClick = { showAddDialog = true },
        containerColor = EmeraldGreenPrimary,
        contentColor = Color.White,
        modifier = Modifier.testTag("add_supplier_fab")
      ) {
        Icon(Icons.Default.Add, contentDescription = "নতুন মহাজন যোগ করুন")
      }
    }
  ) { padding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(horizontal = 16.dp),
      contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // Header & Total Payable Card
      item {
        Column {
          Text(
            text = "মহাজন / পাইকার খাতা",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
          Text(
            text = "পাইকারি পণ্যের ক্রয় রশিদ ও মহাজনদের দেনা-পাওনার হিসাব",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "সর্বমোট মহাজন দেনা (প্রদেয়)",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Text(
                text = DokanFormatter.formatMoney(totalPayable),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = CrimsonDue
              )
            }

            Surface(
              color = CrimsonDue.copy(alpha = 0.12f),
              shape = RoundedCornerShape(12.dp)
            ) {
              Text(
                text = "${suppliers.size} জন মহাজন",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                color = CrimsonDue,
                fontWeight = FontWeight.SemiBold,
                style = MaterialTheme.typography.bodySmall
              )
            }
          }
        }
      }

      // Search Bar
      item {
        OutlinedTextField(
          value = supplierSearch,
          onValueChange = { viewModel.setSupplierSearch(it) },
          placeholder = { Text("মহাজনের নাম, কোম্পানি বা ফোন নম্বর দিয়ে খুঁজুন...") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("supplier_search_input"),
          shape = RoundedCornerShape(14.dp),
          singleLine = true
        )
      }

      // Supplier List
      if (filteredSuppliers.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 40.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Icon(
                imageVector = Icons.Default.Business,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                modifier = Modifier.size(48.dp)
              )
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "কোনো মহাজন পাওয়া যায়নি",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      } else {
        items(filteredSuppliers, key = { it.id }) { supplier ->
          val payable = supplierPayables[supplier.id] ?: supplier.opening

          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Box(
                    modifier = Modifier
                      .size(44.dp)
                      .clip(CircleShape)
                      .background(AmberAccent.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                  ) {
                    Text(
                      text = supplier.name.take(1),
                      fontWeight = FontWeight.Bold,
                      color = AmberAccent,
                      fontSize = 18.sp
                    )
                  }
                  Spacer(modifier = Modifier.width(12.dp))
                  Column {
                    Text(
                      text = supplier.name,
                      style = MaterialTheme.typography.titleMedium,
                      fontWeight = FontWeight.Bold
                    )
                    if (supplier.company.isNotBlank()) {
                      Text(
                        text = supplier.company,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                    }
                    if (supplier.phone.isNotBlank()) {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                          Icons.Default.Call,
                          contentDescription = null,
                          modifier = Modifier.size(12.dp),
                          tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                          text = supplier.phone,
                          style = MaterialTheme.typography.bodySmall,
                          color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                      }
                    }
                  }
                }

                Column(horizontalAlignment = Alignment.End) {
                  Text(
                    text = "প্রদেয় দেনা",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                  Text(
                    text = DokanFormatter.formatMoney(payable),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (payable > 0) CrimsonDue else EmeraldGreenPrimary
                  )
                }
              }

              Spacer(modifier = Modifier.height(12.dp))

              // Action Buttons
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                OutlinedButton(
                  onClick = { supplierToRestock = supplier },
                  modifier = Modifier
                    .weight(1f)
                    .height(38.dp),
                  shape = RoundedCornerShape(8.dp)
                ) {
                  Icon(Icons.Default.ShoppingBag, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("মাল ক্রয় (রিস্টক)", fontSize = 12.sp)
                }

                Button(
                  onClick = { supplierToPay = supplier },
                  modifier = Modifier
                    .weight(1f)
                    .height(38.dp),
                  shape = RoundedCornerShape(8.dp),
                  colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreenPrimary)
                ) {
                  Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("দেনা পরিশোধ", fontSize = 12.sp)
                }

                IconButton(
                  onClick = { viewModel.deleteSupplier(supplier.id) },
                  modifier = Modifier.size(38.dp)
                ) {
                  Icon(
                    Icons.Default.Delete,
                    contentDescription = "মুছুন",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.size(18.dp)
                  )
                }
              }
            }
          }
        }
      }
    }
  }

  // Add Supplier Dialog
  if (showAddDialog) {
    var name by remember { mutableStateOf("") }
    var company by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var openingText by remember { mutableStateOf("0") }

    AlertDialog(
      onDismissRequest = { showAddDialog = false },
      title = { Text("নতুন মহাজন / পাইকার যোগ") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("মহাজনের নাম *") },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("supplier_name_input")
          )
          OutlinedTextField(
            value = company,
            onValueChange = { company = it },
            label = { Text("প্রতিষ্ঠানের নাম (কোম্পানি)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("মোবাইল নম্বর") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = openingText,
            onValueChange = { openingText = it },
            label = { Text("পূর্বের বকেয়া/দেনা (যদি থাকে)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (name.isNotBlank()) {
              val supp = Supplier(
                id = UUID.randomUUID().toString(),
                name = name.trim(),
                company = company.trim(),
                phone = phone.trim(),
                opening = openingText.toDoubleOrNull() ?: 0.0
              )
              viewModel.saveSupplier(supp) {
                showAddDialog = false
              }
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreenPrimary),
          modifier = Modifier.testTag("confirm_add_supplier")
        ) {
          Text("সংরক্ষণ করুন")
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddDialog = false }) {
          Text("বাতিল")
        }
      }
    )
  }

  // Pay Supplier Dialog
  if (supplierToPay != null) {
    val supplier = supplierToPay!!
    val currentPayable = supplierPayables[supplier.id] ?: supplier.opening
    var payAmountText by remember { mutableStateOf(if (currentPayable > 0) currentPayable.toString().replace(".0", "") else "") }
    var selectedAccountId by remember { mutableStateOf("cash") }
    var note by remember { mutableStateOf("") }

    AlertDialog(
      onDismissRequest = { supplierToPay = null },
      title = { Text("${supplier.name} - দেনা পরিশোধ") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text(
            text = "বর্তমান পাওনা: ${DokanFormatter.formatMoney(currentPayable)}",
            fontWeight = FontWeight.SemiBold,
            color = CrimsonDue
          )

          OutlinedTextField(
            value = payAmountText,
            onValueChange = { payAmountText = it },
            label = { Text("পরিশোধের পরিমাণ *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("supplier_pay_amount_input")
          )

          Text("টাকা যেখান থেকে দেওয়া হবে:", style = MaterialTheme.typography.bodySmall)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            listOf("cash" to "নগদ", "bkash" to "বিকাশ", "nagad" to "নগদ অ্যাপ", "bank" to "ব্যাংক").forEach { (accId, label) ->
              val isSelected = selectedAccountId == accId
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isSelected) EmeraldGreenPrimary else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                  .weight(1f)
                  .clickable { selectedAccountId = accId }
              ) {
                Text(
                  text = label,
                  modifier = Modifier.padding(vertical = 8.dp),
                  style = MaterialTheme.typography.bodySmall,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                  color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                  fontSize = 11.sp
                )
              }
            }
          }

          OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            label = { Text("নোট / রসিদ নম্বর") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val amount = payAmountText.toDoubleOrNull() ?: 0.0
            if (amount > 0) {
              viewModel.recordSupplierPayment(
                supplierId = supplier.id,
                supplierName = supplier.name,
                amount = amount,
                accountId = selectedAccountId,
                method = selectedAccountId,
                note = note
              ) {
                supplierToPay = null
              }
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreenPrimary),
          modifier = Modifier.testTag("confirm_supplier_payment")
        ) {
          Text("পরিশোধ নিশ্চিত করুন")
        }
      },
      dismissButton = {
        TextButton(onClick = { supplierToPay = null }) {
          Text("বাতিল")
        }
      }
    )
  }

  // Restock / Purchase From Supplier Dialog
  if (supplierToRestock != null) {
    val supplier = supplierToRestock!!
    var selectedProduct by remember { mutableStateOf<Product?>(products.firstOrNull()) }
    var prodDropdownExpanded by remember { mutableStateOf(false) }
    var qtyText by remember { mutableStateOf("10") }
    var buyPriceText by remember { mutableStateOf(selectedProduct?.buy?.toString()?.replace(".0", "") ?: "100") }
    var paidAmountText by remember { mutableStateOf("") }
    var selectedAccountId by remember { mutableStateOf("cash") }
    var purchaseNote by remember { mutableStateOf("") }

    val qty = qtyText.toDoubleOrNull() ?: 0.0
    val buyPrice = buyPriceText.toDoubleOrNull() ?: 0.0
    val totalPurchaseCost = qty * buyPrice
    val paid = paidAmountText.toDoubleOrNull() ?: totalPurchaseCost
    val remainingDue = (totalPurchaseCost - paid).coerceAtLeast(0.0)

    AlertDialog(
      onDismissRequest = { supplierToRestock = null },
      title = { Text("${supplier.name} থেকে পণ্য ক্রয় (রিস্টক)") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          // Product Picker
          ExposedDropdownMenuBox(
            expanded = prodDropdownExpanded,
            onExpandedChange = { prodDropdownExpanded = !prodDropdownExpanded }
          ) {
            OutlinedTextField(
              value = selectedProduct?.let { "${it.name} (বর্তমান স্টক: ${it.stock} ${it.unit})" } ?: "",
              onValueChange = {},
              readOnly = true,
              label = { Text("ক্রয়কৃত পণ্য") },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = prodDropdownExpanded) },
              modifier = Modifier
                .menuAnchor()
                .fillMaxWidth(),
              shape = RoundedCornerShape(8.dp)
            )

            ExposedDropdownMenu(
              expanded = prodDropdownExpanded,
              onDismissRequest = { prodDropdownExpanded = false }
            ) {
              products.forEach { prod ->
                DropdownMenuItem(
                  text = { Text("${prod.name} (ক্রয়: ${DokanFormatter.formatMoney(prod.buy)})") },
                  onClick = {
                    selectedProduct = prod
                    buyPriceText = prod.buy.toString().replace(".0", "")
                    prodDropdownExpanded = false
                  }
                )
              }
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedTextField(
              value = qtyText,
              onValueChange = { qtyText = it },
              label = { Text("পরিমাণ (${selectedProduct?.unit ?: "টি"})") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              modifier = Modifier.weight(1f)
            )

            OutlinedTextField(
              value = buyPriceText,
              onValueChange = { buyPriceText = it },
              label = { Text("একক ক্রয়মূল্য") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              modifier = Modifier.weight(1f)
            )
          }

          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("মোট ক্রয় বিল:")
              Text(
                DokanFormatter.formatMoney(totalPurchaseCost),
                fontWeight = FontWeight.Bold,
                color = EmeraldGreenPrimary
              )
            }
          }

          OutlinedTextField(
            value = paidAmountText,
            onValueChange = { paidAmountText = it },
            label = { Text("তাৎক্ষণিক নগদ প্রদান") },
            placeholder = { Text(totalPurchaseCost.toString()) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          if (remainingDue > 0) {
            Text(
              text = "মহাজন বাকি থাকবে: ${DokanFormatter.formatMoney(remainingDue)}",
              color = CrimsonDue,
              fontWeight = FontWeight.Bold,
              style = MaterialTheme.typography.bodySmall
            )
          }

          OutlinedTextField(
            value = purchaseNote,
            onValueChange = { purchaseNote = it },
            label = { Text("নোট / ইনভয়েস নং") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val prod = selectedProduct
            if (prod != null && qty > 0 && buyPrice > 0) {
              val items = listOf(
                CartItem(
                  productId = prod.id,
                  name = prod.name,
                  qty = qty,
                  unit = prod.unit,
                  buyPrice = buyPrice,
                  sellPrice = prod.sell,
                  total = totalPurchaseCost
                )
              )

              viewModel.recordPurchase(
                supplierId = supplier.id,
                supplierName = supplier.name,
                items = items,
                paidAmount = paid,
                accountId = selectedAccountId,
                method = selectedAccountId,
                note = purchaseNote
              ) {
                supplierToRestock = null
              }
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreenPrimary),
          modifier = Modifier.testTag("confirm_purchase_button")
        ) {
          Text("ক্রয় সম্পন্ন করুন")
        }
      },
      dismissButton = {
        TextButton(onClick = { supplierToRestock = null }) {
          Text("বাতিল")
        }
      }
    )
  }
}
