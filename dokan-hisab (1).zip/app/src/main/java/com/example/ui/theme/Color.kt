package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dokan Hisab Emerald / Forest Merchant Theme
val EmeraldGreenPrimary = Color(0xFF1B5E20)
val EmeraldGreenDark = Color(0xFF0E3813)
val EmeraldGreenLight = Color(0xFF4C8C4A)
val MintContainer = Color(0xFFE8F5E9)
val OnMintContainer = Color(0xFF002204)

val AmberAccent = Color(0xFFF57F17)
val AmberContainer = Color(0xFFFFF8E1)
val OnAmberContainer = Color(0xFF5D3000)

val CrimsonDue = Color(0xFFC62828)
val CrimsonDueContainer = Color(0xFFFFEBEE)

val SurfaceLight = Color(0xFFFBFDF8)
val CardSurface = Color(0xFFFFFFFF)
val OutlineVariantLight = Color(0xFFE0E0E0)
val OutlineBorder = Color(0xFFBDBDBD)

val TextPrimary = Color(0xFF191C19)
val TextSecondary = Color(0xFF536254)
val TextMuted = Color(0xFF748775)

// Dark theme colors
val EmeraldGreenPrimaryDark = Color(0xFF81C784)
val SurfaceDark = Color(0xFF111411)
val CardSurfaceDark = Color(0xFF1E231E)
val TextPrimaryDark = Color(0xFFE1E3DF)
val TextSecondaryDark = Color(0xFFA4AAA3)
