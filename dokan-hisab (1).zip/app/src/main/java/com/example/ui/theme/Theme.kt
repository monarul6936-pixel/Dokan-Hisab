package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = EmeraldGreenPrimaryDark,
  onPrimary = Color(0xFF00390B),
  primaryContainer = EmeraldGreenDark,
  onPrimaryContainer = MintContainer,
  secondary = AmberAccent,
  onSecondary = Color.Black,
  secondaryContainer = Color(0xFF4A3400),
  onSecondaryContainer = AmberContainer,
  background = SurfaceDark,
  onBackground = TextPrimaryDark,
  surface = CardSurfaceDark,
  onSurface = TextPrimaryDark,
  surfaceVariant = Color(0xFF283028),
  onSurfaceVariant = TextSecondaryDark,
  outline = Color(0xFF4A554A),
  error = Color(0xFFFFB4AB),
  errorContainer = Color(0xFF93000A)
)

private val LightColorScheme = lightColorScheme(
  primary = EmeraldGreenPrimary,
  onPrimary = Color.White,
  primaryContainer = MintContainer,
  onPrimaryContainer = OnMintContainer,
  secondary = AmberAccent,
  onSecondary = Color.White,
  secondaryContainer = AmberContainer,
  onSecondaryContainer = OnAmberContainer,
  background = SurfaceLight,
  onBackground = TextPrimary,
  surface = CardSurface,
  onSurface = TextPrimary,
  surfaceVariant = Color(0xFFF1F5F0),
  onSurfaceVariant = TextSecondary,
  outline = OutlineBorder,
  outlineVariant = OutlineVariantLight,
  error = CrimsonDue,
  errorContainer = CrimsonDueContainer
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // For distinct Dokan branding, use our curated emerald palette by default
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
