package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.data.model.Account
import com.example.data.model.CartItem
import com.example.data.model.Customer
import com.example.data.model.Product
import com.example.data.model.ShopInfo
import com.example.data.model.Supplier
import com.example.data.model.Transaction
import com.example.data.repository.FirestoreDokanRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class DateRangeFilter(val label: String) {
  TODAY("আজকের"),
  THIS_MONTH("চলতি মাস"),
  ALL_TIME("সর্বমোট")
}

data class FinancialReport(
  val todaySales: Double = 0.0,
  val totalSales: Double = 0.0,
  val todayExpenses: Double = 0.0,
  val totalExpenses: Double = 0.0,
  val costOfGoodsSold: Double = 0.0,
  val grossProfit: Double = 0.0,
  val operatingExpenses: Double = 0.0,
  val netProfit: Double = 0.0,
  val totalCustomerDue: Double = 0.0,
  val totalDue: Double = 0.0,
  val totalSupplierPayable: Double = 0.0,
  val totalStockCostValue: Double = 0.0,
  val totalStockRetailValue: Double = 0.0,
  val stockValue: Double = 0.0,
  val totalLiquidFunds: Double = 0.0,
  val lowStockCount: Int = 0
)

class DokanViewModel(application: Application) : AndroidViewModel(application) {
  private val auth: FirebaseAuth = Firebase.auth
  private val db: FirebaseFirestore
  private val repository: FirestoreDokanRepository

  private val _currentUser = MutableStateFlow<FirebaseUser?>(auth.currentUser)
  val currentUser: StateFlow<FirebaseUser?> = _currentUser.asStateFlow()

  init {
    val databaseId = application.getString(R.string.firestore_database_id)
    db = FirebaseFirestore.getInstance(databaseId)
    repository = FirestoreDokanRepository(db, auth)

    auth.addAuthStateListener { firebaseAuth ->
      _currentUser.value = firebaseAuth.currentUser
      if (firebaseAuth.currentUser != null) {
        viewModelScope.launch {
          repository.seedInitialDataIfEmpty()
        }
      }
    }

    viewModelScope.launch {
      if (auth.currentUser != null) {
        repository.seedInitialDataIfEmpty()
      }
    }
  }

  // --- Real-time Flows ---

  val products: StateFlow<List<Product>> = repository.observeProducts()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val customers: StateFlow<List<Customer>> = repository.observeCustomers()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val suppliers: StateFlow<List<Supplier>> = repository.observeSuppliers()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val accounts: StateFlow<List<Account>> = repository.observeAccounts()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val transactions: StateFlow<List<Transaction>> = repository.observeTransactions()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val shopInfo: StateFlow<ShopInfo?> = repository.observeShopInfo()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  // --- Multi-Item POS Cart State ---

  private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
  val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

  val cartTotal: StateFlow<Double> = _cart.combine(MutableStateFlow(Unit)) { items, _ ->
    items.sumOf { it.total }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

  val cartCost: StateFlow<Double> = _cart.combine(MutableStateFlow(Unit)) { items, _ ->
    items.sumOf { it.qty * it.buyPrice }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

  val cartProfit: StateFlow<Double> = combine(cartTotal, cartCost) { total, cost ->
    total - cost
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

  // --- Search & Filters ---

  private val _productSearch = MutableStateFlow("")
  val productSearch: StateFlow<String> = _productSearch.asStateFlow()

  private val _customerSearch = MutableStateFlow("")
  val customerSearch: StateFlow<String> = _customerSearch.asStateFlow()

  private val _supplierSearch = MutableStateFlow("")
  val supplierSearch: StateFlow<String> = _supplierSearch.asStateFlow()

  private val _reportDateFilter = MutableStateFlow(DateRangeFilter.TODAY)
  val reportDateFilter: StateFlow<DateRangeFilter> = _reportDateFilter.asStateFlow()

  // UI notifications
  private val _userMessage = MutableSharedFlow<String>()
  val userMessage: SharedFlow<String> = _userMessage.asSharedFlow()

  fun notify(msg: String) {
    viewModelScope.launch {
      _userMessage.emit(msg)
    }
  }

  fun setProductSearch(q: String) { _productSearch.value = q }
  fun setCustomerSearch(q: String) { _customerSearch.value = q }
  fun setSupplierSearch(q: String) { _supplierSearch.value = q }
  fun setReportDateFilter(f: DateRangeFilter) { _reportDateFilter.value = f }

  // --- Dues & Payables Calculations ---

  val customerDues: StateFlow<Map<String, Double>> = combine(customers, transactions) { custList, txList ->
    custList.associate { c ->
      val credits = txList.filter { it.customerId == c.id && (it.type == "credit_sale" || (it.type == "sale" && it.dueAmount > 0)) }
        .sumOf { if (it.type == "credit_sale") it.amount else it.dueAmount }
      val collections = txList.filter { it.customerId == c.id && it.type == "collection" }.sumOf { it.amount }
      c.id to (c.opening + credits - collections)
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

  val supplierPayables: StateFlow<Map<String, Double>> = combine(suppliers, transactions) { suppList, txList ->
    suppList.associate { s ->
      val purchases = txList.filter { it.supplierId == s.id && it.type == "purchase" }
        .sumOf { it.dueAmount }
      val payments = txList.filter { it.supplierId == s.id && it.type == "supplier_payment" }.sumOf { it.amount }
      s.id to (s.opening + purchases - payments)
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

  // --- Financial Report Analytics Engine ---

  private data class DokanCombinedData(
    val products: List<Product>,
    val customers: List<Customer>,
    val suppliers: List<Supplier>,
    val accounts: List<Account>,
    val transactions: List<Transaction>
  )

  private val combinedDataFlow = combine(
    products, customers, suppliers, accounts, transactions
  ) { prodList, custList, suppList, accList, txList ->
    DokanCombinedData(prodList, custList, suppList, accList, txList)
  }

  val financialReport: StateFlow<FinancialReport> = combine(
    combinedDataFlow, reportDateFilter
  ) { data, filter ->
    val prodList = data.products
    val custList = data.customers
    val suppList = data.suppliers
    val accList = data.accounts
    val txList = data.transactions

    val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    val currentMonthPrefix = today.substring(0, 7) // e.g. "2026-10"

    val filteredTxs = when (filter) {
      DateRangeFilter.TODAY -> txList.filter { it.date == today }
      DateRangeFilter.THIS_MONTH -> txList.filter { it.date.startsWith(currentMonthPrefix) }
      DateRangeFilter.ALL_TIME -> txList
    }

    val salesTxs = filteredTxs.filter { it.type == "sale" || it.type == "credit_sale" }
    val expenseTxs = filteredTxs.filter { it.type == "expense" }

    val totalSales = salesTxs.sumOf { it.amount }
    val grossProfit = salesTxs.sumOf { it.profit ?: 0.0 }
    val costOfGoodsSold = totalSales - grossProfit
    val operatingExpenses = expenseTxs.sumOf { it.amount }
    val netProfit = grossProfit - operatingExpenses

    // Today's specific metrics
    val todaySalesTxs = txList.filter { it.date == today && (it.type == "sale" || it.type == "credit_sale") }
    val todayExpenseTxs = txList.filter { it.date == today && it.type == "expense" }
    val todaySales = todaySalesTxs.sumOf { it.amount }
    val todayExpenses = todayExpenseTxs.sumOf { it.amount }

    // Receivables & Payables are cumulative current balances
    val totalCustDue = custList.sumOf { c ->
      val credits = txList.filter { it.customerId == c.id && (it.type == "credit_sale" || (it.type == "sale" && it.dueAmount > 0)) }
        .sumOf { if (it.type == "credit_sale") it.amount else it.dueAmount }
      val collections = txList.filter { it.customerId == c.id && it.type == "collection" }.sumOf { it.amount }
      (c.opening + credits - collections).coerceAtLeast(0.0)
    }

    val totalSuppPayable = suppList.sumOf { s ->
      val purchases = txList.filter { it.supplierId == s.id && it.type == "purchase" }.sumOf { it.dueAmount }
      val payments = txList.filter { it.supplierId == s.id && it.type == "supplier_payment" }.sumOf { it.amount }
      (s.opening + purchases - payments).coerceAtLeast(0.0)
    }

    val stockCostValue = prodList.sumOf { it.buy * it.stock }
    val stockRetailValue = prodList.sumOf { it.sell * it.stock }
    val totalLiquidFunds = accList.sumOf { it.balance }
    val lowStockCount = prodList.count { it.stock <= 5.0 }

    FinancialReport(
      todaySales = todaySales,
      totalSales = totalSales,
      todayExpenses = todayExpenses,
      totalExpenses = operatingExpenses,
      costOfGoodsSold = costOfGoodsSold,
      grossProfit = grossProfit,
      operatingExpenses = operatingExpenses,
      netProfit = netProfit,
      totalCustomerDue = totalCustDue,
      totalDue = totalCustDue,
      totalSupplierPayable = totalSuppPayable,
      totalStockCostValue = stockCostValue,
      totalStockRetailValue = stockRetailValue,
      stockValue = stockCostValue,
      totalLiquidFunds = totalLiquidFunds,
      lowStockCount = lowStockCount
    )
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FinancialReport())

  val summary: StateFlow<FinancialReport> = financialReport

  val recentTransactions: StateFlow<List<Transaction>> = transactions.map {
    it.take(20)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val shopName: StateFlow<String> = shopInfo.map {
    it?.name?.ifBlank { "আমার মুদি দোকান" } ?: "আমার মুদি দোকান"
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "আমার মুদি দোকান")

  fun updateShopName(newName: String) {
    updateShopInfo(newName, "", "")
  }

  fun signOut() {
    auth.signOut()
    _currentUser.value = null
  }

  // --- Cart Management ---

  fun addToCart(product: Product, quantity: Double) {
    if (quantity <= 0) return
    val current = _cart.value.toMutableList()
    val existingIndex = current.indexOfFirst { it.productId == product.id }

    if (existingIndex >= 0) {
      val existing = current[existingIndex]
      val newQty = existing.qty + quantity
      current[existingIndex] = existing.copy(
        qty = newQty,
        total = newQty * existing.sellPrice
      )
    } else {
      current.add(
        CartItem(
          productId = product.id,
          name = product.name,
          qty = quantity,
          unit = product.unit,
          buyPrice = product.buy,
          sellPrice = product.sell,
          total = quantity * product.sell
        )
      )
    }
    _cart.value = current
  }

  fun updateCartItemQty(productId: String, newQty: Double) {
    if (newQty <= 0) {
      removeFromCart(productId)
      return
    }
    _cart.value = _cart.value.map { item ->
      if (item.productId == productId) {
        item.copy(qty = newQty, total = newQty * item.sellPrice)
      } else item
    }
  }

  fun removeFromCart(productId: String) {
    _cart.value = _cart.value.filter { it.productId != productId }
  }

  fun clearCart() {
    _cart.value = emptyList()
  }

  // --- POS Sale Checkout ---

  fun checkoutSale(
    method: String,
    accountId: String,
    customerId: String?,
    customerName: String?,
    paidAmount: Double,
    note: String,
    onSuccess: () -> Unit
  ) {
    viewModelScope.launch {
      val items = _cart.value
      if (items.isEmpty()) {
        notify("কার্ট খালি! পণ্য যোগ করুন")
        return@launch
      }

      val res = repository.recordSale(
        items = items,
        method = method,
        accountId = accountId,
        customerId = customerId,
        customerName = customerName,
        paidAmount = paidAmount,
        note = note
      )

      if (res.isSuccess) {
        clearCart()
        notify("বিক্রি সফলভাবে সম্পন্ন হয়েছে")
        onSuccess()
      } else {
        notify(res.exceptionOrNull()?.message ?: "বিক্রি সংরক্ষণ করা যায়নি")
      }
    }
  }

  // --- Supplier Purchase Restock ---

  fun recordPurchase(
    supplierId: String?,
    supplierName: String?,
    items: List<CartItem>,
    paidAmount: Double,
    accountId: String,
    method: String,
    note: String,
    onSuccess: () -> Unit
  ) {
    viewModelScope.launch {
      val res = repository.recordPurchase(
        supplierId = supplierId,
        supplierName = supplierName,
        items = items,
        paidAmount = paidAmount,
        accountId = accountId,
        method = method,
        note = note
      )
      if (res.isSuccess) {
        notify("পণ্য ক্রয় ও মজুদ সফলভাবে আপডেট হয়েছে")
        onSuccess()
      } else {
        notify(res.exceptionOrNull()?.message ?: "ক্রয় সংরক্ষণ ব্যর্থ হয়েছে")
      }
    }
  }

  // --- Customer Debt Collection ---

  fun recordCustomerCollection(
    customerId: String,
    customerName: String,
    amount: Double,
    accountId: String,
    method: String,
    note: String,
    onSuccess: () -> Unit
  ) {
    viewModelScope.launch {
      val res = repository.recordCustomerCollection(customerId, customerName, amount, accountId, method, note)
      if (res.isSuccess) {
        notify("বাকি আদায় ও ক্যাশ জমা সফলভাবে সম্পন্ন হয়েছে")
        onSuccess()
      } else {
        notify(res.exceptionOrNull()?.message ?: "আদায় সংরক্ষণ করা যায়নি")
      }
    }
  }

  // --- Supplier Payment ---

  fun recordSupplierPayment(
    supplierId: String,
    supplierName: String,
    amount: Double,
    accountId: String,
    method: String,
    note: String,
    onSuccess: () -> Unit
  ) {
    viewModelScope.launch {
      val res = repository.recordSupplierPayment(supplierId, supplierName, amount, accountId, method, note)
      if (res.isSuccess) {
        notify("মহাজন দেনা পরিশোধ সম্পন্ন হয়েছে")
        onSuccess()
      } else {
        notify(res.exceptionOrNull()?.message ?: "পেমেন্ট সংরক্ষণ করা যায়নি")
      }
    }
  }

  // --- Operating Expense ---

  fun recordExpense(
    note: String,
    amount: Double,
    accountId: String,
    method: String,
    onSuccess: () -> Unit
  ) {
    viewModelScope.launch {
      val res = repository.recordExpense(note, amount, accountId, method)
      if (res.isSuccess) {
        notify("দোকানের খরচ সংরক্ষিত হয়েছে")
        onSuccess()
      } else {
        notify(res.exceptionOrNull()?.message ?: "খরচ সংরক্ষণ করা যায়নি")
      }
    }
  }

  // --- Inter-Account Transfer ---

  fun recordTransfer(
    fromAccountId: String,
    toAccountId: String,
    amount: Double,
    note: String,
    onSuccess: () -> Unit
  ) {
    viewModelScope.launch {
      val res = repository.recordTransfer(fromAccountId, toAccountId, amount, note)
      if (res.isSuccess) {
        notify("টাকা স্থানান্তর সম্পন্ন হয়েছে")
        onSuccess()
      } else {
        notify(res.exceptionOrNull()?.message ?: "স্থানান্তর ব্যর্থ হয়েছে")
      }
    }
  }

  // --- General Cash In/Out ---

  fun recordOtherTransaction(
    direction: String,
    note: String,
    amount: Double,
    accountId: String,
    method: String,
    onSuccess: () -> Unit
  ) {
    viewModelScope.launch {
      val res = repository.recordOtherTransaction(direction, note, amount, accountId, method)
      if (res.isSuccess) {
        notify("লেনদেন সংরক্ষিত হয়েছে")
        onSuccess()
      } else {
        notify(res.exceptionOrNull()?.message ?: "সংরক্ষণ করা যায়নি")
      }
    }
  }

  // --- Entity CRUD Operations ---

  fun saveProduct(
    id: String? = null,
    name: String,
    buy: Double,
    sell: Double,
    stock: Double,
    unit: String,
    onSuccess: () -> Unit
  ) {
    val prod = Product(
      id = if (id.isNullOrBlank()) java.util.UUID.randomUUID().toString() else id,
      name = name,
      buy = buy,
      sell = sell,
      stock = stock,
      unit = unit
    )
    saveProduct(prod, onSuccess)
  }

  fun saveProduct(product: Product, onSuccess: () -> Unit) {
    viewModelScope.launch {
      val res = repository.saveProduct(product)
      if (res.isSuccess) {
        notify("পণ্যের তথ্য সফলভাবে সংরক্ষিত হয়েছে")
        onSuccess()
      } else {
        notify(res.exceptionOrNull()?.message ?: "পণ্য সংরক্ষণ করা যায়নি")
      }
    }
  }

  fun deleteProduct(id: String) {
    viewModelScope.launch {
      repository.deleteProduct(id)
      notify("পণ্যটি মুছে ফেলা হয়েছে")
    }
  }

  fun saveCustomer(
    id: String? = null,
    name: String,
    phone: String,
    opening: Double,
    onSuccess: () -> Unit
  ) {
    val cust = Customer(
      id = if (id.isNullOrBlank()) java.util.UUID.randomUUID().toString() else id,
      name = name,
      phone = phone,
      opening = opening
    )
    saveCustomer(cust, onSuccess)
  }

  fun saveCustomer(customer: Customer, onSuccess: () -> Unit) {
    viewModelScope.launch {
      val res = repository.saveCustomer(customer)
      if (res.isSuccess) {
        notify("কাস্টমার সফলভাবে সংরক্ষিত হয়েছে")
        onSuccess()
      } else {
        notify(res.exceptionOrNull()?.message ?: "কাস্টমার সংরক্ষণ করা যায়নি")
      }
    }
  }

  fun addOtherTransaction(
    direction: String,
    note: String,
    amount: Double,
    accountId: String = "cash",
    method: String = "cash",
    onSuccess: () -> Unit
  ) {
    recordOtherTransaction(direction, note, amount, accountId, method, onSuccess)
  }

  fun deleteCustomer(id: String) {
    viewModelScope.launch {
      repository.deleteCustomer(id)
      notify("কাস্টমার মুছে ফেলা হয়েছে")
    }
  }

  fun saveSupplier(supplier: Supplier, onSuccess: () -> Unit) {
    viewModelScope.launch {
      val res = repository.saveSupplier(supplier)
      if (res.isSuccess) {
        notify("মহাজন/সাপ্লায়ার তথ্য সংরক্ষিত হয়েছে")
        onSuccess()
      } else {
        notify(res.exceptionOrNull()?.message ?: "সাপ্লায়ার সংরক্ষণ করা যায়নি")
      }
    }
  }

  fun deleteSupplier(id: String) {
    viewModelScope.launch {
      repository.deleteSupplier(id)
      notify("মহাজন/সাপ্লায়ার মুছে ফেলা হয়েছে")
    }
  }

  fun updateShopInfo(name: String, phone: String, address: String) {
    viewModelScope.launch {
      val res = repository.updateShopInfo(name, phone, address)
      if (res.isSuccess) {
        notify("দোকানের তথ্য সংরক্ষিত হয়েছে")
      } else {
        notify(res.exceptionOrNull()?.message ?: "সংরক্ষণ ব্যর্থ হয়েছে")
      }
    }
  }

  fun updateAccountBalance(accountId: String, newBalance: Double) {
    viewModelScope.launch {
      val res = repository.updateAccountBalance(accountId, newBalance)
      if (res.isSuccess) {
        notify("ব্যালেন্স আপডেট হয়েছে")
      }
    }
  }

  fun addCollection(
    customerId: String,
    amount: Double,
    method: String,
    onSuccess: () -> Unit
  ) {
    val custName = customers.value.find { it.id == customerId }?.name ?: ""
    recordCustomerCollection(
      customerId = customerId,
      customerName = custName,
      amount = amount,
      accountId = method,
      method = method,
      note = "বাকি আদায় ($custName)",
      onSuccess = onSuccess
    )
  }

  fun addExpense(
    note: String,
    amount: Double,
    method: String,
    onSuccess: () -> Unit
  ) {
    recordExpense(note, amount, method, method, onSuccess)
  }

  fun quickRestock(productId: String, addQty: Double) {
    val prod = products.value.find { it.id == productId } ?: return
    saveProduct(prod.copy(stock = prod.stock + addQty)) {}
  }

  fun onUserSignedIn() {
    viewModelScope.launch {
      repository.seedInitialDataIfEmpty()
    }
  }
}
