package com.example.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.Account
import com.example.data.model.CartItem
import com.example.data.model.Customer
import com.example.data.model.Product
import com.example.data.repository.FirestoreDokanRepository
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class DokanRepositoryRuleTest : FirestoreEmulatorTestBase() {

  @Test
  fun testAuthenticatedOwnerCanSaveProductAndRecordSale() = runBlocking {
    val email = "user_${UUID.randomUUID()}@example.com"
    auth.createUserWithEmailAndPassword(email, "password123").await()
    val uid = auth.currentUser!!.uid

    val repository = FirestoreDokanRepository(firestore, auth)

    // Save initial cash account
    firestore.collection("users").document(uid).collection("accounts").document("cash")
      .set(Account(id = "cash", userId = uid, name = "নগদ ক্যাশ", balance = 1000.0, type = "cash"))
      .await()

    // 1. Save product
    val prod = Product(id = "p_rice", userId = uid, name = "মিনিকেট চাল", buy = 3000.0, sell = 3400.0, stock = 10.0, unit = "বস্তা")
    val saveRes = repository.saveProduct(prod)
    assertTrue("Product save should succeed", saveRes.isSuccess)

    // 2. Record multi-item sale
    val cartItems = listOf(
      CartItem(productId = "p_rice", name = "মিনিকেট চাল", qty = 2.0, unit = "বস্তা", buyPrice = 3000.0, sellPrice = 3400.0, total = 6800.0)
    )
    val saleRes = repository.recordSale(
      items = cartItems,
      method = "cash",
      accountId = "cash",
      customerId = null,
      customerName = null,
      paidAmount = 6800.0,
      note = "চাল বিক্রি"
    )
    assertTrue("Sale should succeed: ${saleRes.exceptionOrNull()?.message} cause: ${saleRes.exceptionOrNull()?.cause?.message}", saleRes.isSuccess)

    // Check stock updated
    val updatedProdDoc = firestore.collection("users").document(uid).collection("products").document("p_rice").get().await()
    assertEquals(8.0, updatedProdDoc.getDouble("stock") ?: 0.0, 0.01)

    // Check cash account updated
    val updatedAccDoc = firestore.collection("users").document(uid).collection("accounts").document("cash").get().await()
    assertEquals(7800.0, updatedAccDoc.getDouble("balance") ?: 0.0, 0.01)
  }

  @Test
  fun testUnauthenticatedFails() = runBlocking {
    val email = "user_${UUID.randomUUID()}@example.com"
    auth.createUserWithEmailAndPassword(email, "password123").await()
    val uid = auth.currentUser!!.uid

    val repository = FirestoreDokanRepository(firestore, auth)

    // Sign out
    auth.signOut()

    val saveRes = repository.saveProduct(Product(id = "p1", userId = uid, name = "তেল", buy = 100.0, sell = 120.0, stock = 5.0, unit = "লিটার"))
    assertTrue("Should have failed when unauthenticated", saveRes.isFailure)
  }
}
