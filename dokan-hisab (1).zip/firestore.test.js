const { initializeTestEnvironment, assertFails, assertSucceeds } = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

const PROJECT_ID = "demo-no-project";
let testEnv;

before(async () => {
  const rules = fs.readFileSync("firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules: rules,
      host: "127.0.0.1",
      port: 8085
    }
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("unauthenticated user cannot read products", async () => {
  const unauthedDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthedDb.doc("users/user123/products/prod1").get());
});

test("authenticated owner can create and read products", async () => {
  const ownerDb = testEnv.authenticatedContext("user123").firestore();
  const prodRef = ownerDb.doc("users/user123/products/prod1");

  await assertSucceeds(prodRef.set({
    userId: "user123",
    name: "মিনিকেট চাল",
    buy: 3200,
    sell: 3450,
    stock: 10,
    unit: "বস্তা"
  }));

  await assertSucceeds(prodRef.get());
});

test("user cannot read another user's products (multi-user isolation)", async () => {
  const user1Db = testEnv.authenticatedContext("user1").firestore();
  const user2Db = testEnv.authenticatedContext("user2").firestore();

  await assertSucceeds(user1Db.doc("users/user1/products/prod1").set({
    userId: "user1",
    name: "চিনি",
    buy: 120,
    sell: 135,
    stock: 20,
    unit: "কেজি"
  }));

  await assertFails(user2Db.doc("users/user1/products/prod1").get());
  await assertFails(user2Db.doc("users/user1/products/prod1").set({
    userId: "user1",
    name: "হ্যাকড চিনি",
    buy: 0,
    sell: 0,
    stock: 0,
    unit: "কেজি"
  }));
});

test("owner can create customer, supplier, account, and transaction", async () => {
  const ownerDb = testEnv.authenticatedContext("user123").firestore();

  // Customer
  await assertSucceeds(ownerDb.doc("users/user123/customers/cust1").set({
    userId: "user123",
    name: "রহিম সাহেব",
    phone: "01711223344",
    opening: 500
  }));

  // Supplier
  await assertSucceeds(ownerDb.doc("users/user123/suppliers/supp1").set({
    userId: "user123",
    name: "মোশাররফ ভাই",
    company: "মেঘনা গ্রুপ ডিলার",
    phone: "01811223344",
    opening: 12000
  }));

  // Account
  await assertSucceeds(ownerDb.doc("users/user123/accounts/cash").set({
    userId: "user123",
    name: "নগদ ক্যাশ বাক্স",
    balance: 5500,
    type: "cash"
  }));

  // Transaction
  await assertSucceeds(ownerDb.doc("users/user123/transactions/tx1").set({
    userId: "user123",
    date: "2026-10-25",
    type: "sale",
    amount: 850,
    paidAmount: 850,
    dueAmount: 0,
    method: "cash",
    accountId: "cash",
    note: "সয়াবিন তেল ও চিনি বিক্রি",
    profit: 90,
    items: [
      { productId: "p1", name: "সয়াবিন তেল", qty: 1, unit: "বোতল", buyPrice: 780, sellPrice: 850, total: 850 }
    ]
  }));
});
